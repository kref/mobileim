/****************************************************************************
**Description: Define the snowflake positons and direction
**
**Author: Johnny Liu
**
**Date: 2011/1/10
**
**Version: 1.1
**
****************************************************************************/

function snowflakeDirection() {
    var position = Qt.point(0, 0);

    position = Qt.point(0, 1000); //The snowflake falling

    return position;
}
