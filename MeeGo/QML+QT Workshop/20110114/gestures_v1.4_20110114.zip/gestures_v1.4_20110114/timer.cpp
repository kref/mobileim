#include "timer.h"
#include <QTime>
#include <QDebug>
#include <QDesktopWidget>
#include <QApplication>
#include <QMouseEvent>
#include <QRect>

MyTimer::MyTimer()
{
    action = false;
    anctionOnMouse = false;
    actionForMove = false;
    hold = true;
    connect(&timer, SIGNAL(timeout()), this, SLOT(sendsig()));
    connect(&holdTimer, SIGNAL(timeout()), this, SLOT(holdAction()));
    timer.start(6*1000);
}

void MyTimer::holdAction()
{
    if( hold )
    {
        qDebug()<<"Hold";
        action = true;
        emit stopScreenSave();
        timer.stop();
        timer.start(6*1000);
        if ( !holdFirstShow )
        {
            holdFirstShow = true;
        }
        emit createBubble(QVariant(x), QVariant(y));
     }
}
void MyTimer::orientationChange(int)
{
    QDesktopWidget* desktop = QApplication::desktop();
    QRect rect = desktop->screenGeometry();
    emit changeRect(rect.width(), rect.height());
}

bool MyTimer::eventFilter(QObject *obj, QEvent *event)
{

    switch(event->type())
    {

    case QEvent::MouseButtonPress:
        {
            QMouseEvent* mouse = static_cast<QMouseEvent*>(event);
            qDebug()<<"Tap";

            action = true;
            hold = true;
            x = mouse->x();
            y = mouse->y();
            emit stopScreenSave();
            timer.stop();
            timer.start(6*1000);
            holdTimer.start(200);
            break;
        }
    case QEvent::MouseButtonDblClick:
        {
            qDebug()<<"Double Tap";
            action = true;
            emit stopScreenSave();
            timer.stop();
            timer.start(6*1000);
            break;
        }
    case QEvent::MouseButtonRelease:
        {
            QMouseEvent* mouse = static_cast<QMouseEvent*>(event);

            if ( actionForMove )
            {
                emit createBubble(0, 0);
            }
            else if( x == mouse->x() && y == mouse->y() || anctionOnMouse )
            {
                emit createBubble(QVariant(x), QVariant(y));
            }

            qDebug()<<"release";
            hold = false;
            anctionOnMouse = false;
            actionForMove = false;
            holdFirstShow = false;
            holdTimer.stop();
            break;
        }
    case QEvent::MouseMove:
        {
            qDebug()<<"move";
            action = true;
            hold = false;
            emit stopScreenSave();
            timer.stop();
            timer.start(6*1000);
            if( !anctionOnMouse )
            {
                anctionOnMouse = true;
            }
            else
            {
                actionForMove = true;
            }
            break;
        }

    default:
        break;
    }
    return qApp->eventFilter(obj, event);
}


