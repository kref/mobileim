#include <QApplication>
#include <QDeclarativeView>
#include <QDeclarativeEngine>
#include <QDeclarativeContext>
#include <QDesktopWidget>
#include <QRect>
#include <QTime>
#include <QGraphicsObject>
#include <QGraphicsScene>
#include <QDeclarativeItem>
#include "timer.h"

int main(int argc, char *argv[])   
{   
    QApplication a(argc, argv);   

    MyTimer* timer = new MyTimer;
    a.installEventFilter(timer);

    QDesktopWidget* desktop = QApplication::desktop();
    QRect rect = desktop->screenGeometry();

    QDeclarativeView* view = new QDeclarativeView;
    QGraphicsScene *scene = new QGraphicsScene(rect);

    QDeclarativeEngine *engine = new QDeclarativeEngine;
    QDeclarativeContext *context = new QDeclarativeContext(engine->rootContext());

    context->setContextProperty("ScreenWidth", rect.width());
    context->setContextProperty("ScreenHeight", rect.height());

    QDeclarativeComponent mainComponent(engine, QUrl("qrc:/main.qml"));
    QObject *mainObject = mainComponent.create(context);
    QDeclarativeItem *mainItem = qobject_cast<QDeclarativeItem*>(mainObject);

    QDeclarativeComponent screenSaveComponent(engine, QUrl("qrc:/GestureCore/Snow.qml"));
    QObject *screenSaveObject = screenSaveComponent.create(context);
    QDeclarativeItem *screenSaveItem = qobject_cast<QDeclarativeItem*>(screenSaveObject);

    QObject::connect(desktop, SIGNAL(resized(int)),  timer, SLOT(orientationChange(int)));
    QObject::connect(timer, SIGNAL(createBubble(QVariant, QVariant)), mainItem, SLOT(createBubble(QVariant, QVariant)));
    QObject::connect(timer, SIGNAL(changeRect(QVariant,QVariant)),  mainItem, SLOT(changeRect(QVariant,QVariant)));
    QObject::connect(timer, SIGNAL(changeRect(QVariant,QVariant)),  screenSaveItem, SLOT(changeRect(QVariant,QVariant)));
    QObject::connect(timer, SIGNAL(noaction()),  screenSaveItem, SLOT(show()));
    QObject::connect(timer, SIGNAL(stopScreenSave()),  screenSaveItem, SLOT(hide()));
    QObject::connect(engine, SIGNAL(quit()), &a, SLOT(quit()));

    view->setScene(scene);
    scene->addItem(mainItem);
    scene->addItem(screenSaveItem);
    view->showFullScreen();
    return a.exec();   
}  
