#ifndef TIMER_H
#define TIMER_H

#include <QTimer>
#include <QVariant>
#include <QEvent>

class MyTimer: public QObject
{
    Q_OBJECT
public:
    MyTimer();
private:
    bool eventFilter(QObject *obj, QEvent *event);

public slots:
   void sendsig()
   {
       if( !action )
       {
       emit noaction();

       }
        action = false;
   }
   void holdAction();
   void orientationChange(int);

signals:
   void noaction();
   void stopScreenSave();
   void createBubble(QVariant x, QVariant y);
   void changeRect(QVariant width, QVariant height);

private:
   QTimer timer;
   QTimer holdTimer;
   bool hold;
   bool action;         //true when any anction
   bool anctionOnMouse;
   bool actionForMove;
   bool holdFirstShow;
   int x;
   int y;

};

#endif // TIMER_H
