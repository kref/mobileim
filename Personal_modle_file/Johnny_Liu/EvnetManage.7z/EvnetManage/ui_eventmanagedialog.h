/********************************************************************************
** Form generated from reading UI file 'eventmanagedialog.ui'
**
** Created: Wed Jul 14 15:53:46 2010
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EVENTMANAGEDIALOG_H
#define UI_EVENTMANAGEDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <qlineeditex.h>

QT_BEGIN_NAMESPACE

class Ui_EventManageDialog
{
public:
    QLineEditEx *lineEdit;

    void setupUi(QDialog *EventManageDialog)
    {
        if (EventManageDialog->objectName().isEmpty())
            EventManageDialog->setObjectName(QString::fromUtf8("EventManageDialog"));
        EventManageDialog->resize(411, 55);
        lineEdit = new QLineEditEx(EventManageDialog);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(30, 20, 113, 20));

        retranslateUi(EventManageDialog);

        QMetaObject::connectSlotsByName(EventManageDialog);
    } // setupUi

    void retranslateUi(QDialog *EventManageDialog)
    {
        EventManageDialog->setWindowTitle(QApplication::translate("EventManageDialog", "EventManageDialog", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class EventManageDialog: public Ui_EventManageDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EVENTMANAGEDIALOG_H
