#ifndef EVENTMANAGEDIALOG_H
#define EVENTMANAGEDIALOG_H

#include <QDialog>
#include <QObject>

class QLabel;
class QLineEdit;
class QPushBotton;
class QLineEditEx;

namespace Ui {
    class EventManageDialog;
}

class EventManageDialog : public QDialog
{
    Q_OBJECT
public:
    EventManageDialog(QWidget *parent = 0);
    ~EventManageDialog();

private:
    Ui::EventManageDialog *ui;

private slots:
    void startBtnclicked();
    void pauseBtnclicked();

private:
    QLabel          *tipLabel;
    QPushButton     *startBtn;
    QPushButton     *pauseBtn;
    QLineEditEx     *tickLineEdit;
};

#endif // EVENTMANAGEDIALOG_H
