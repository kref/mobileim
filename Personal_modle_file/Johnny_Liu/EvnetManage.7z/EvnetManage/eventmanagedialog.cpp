#include "eventmanagedialog.h"
#include "ui_eventmanagedialog.h"
#include <QBoxLayout>
#include <QtGui>

EventManageDialog::EventManageDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EventManageDialog)
{
    ui->setupUi(this);
    this->setWindowTitle("EventM Demo");

    startBtn = new QPushButton("Start");
    pauseBtn = new QPushButton("Stop");
    QHBoxLayout* topLayoutBtn = new QHBoxLayout;
    topLayoutBtn->addWidget(startBtn);
    topLayoutBtn->addWidget(pauseBtn);

    tipLabel = new QLabel(tr("Hi guys!"));
    QHBoxLayout* topLayout = new QHBoxLayout;
    topLayout->addWidget(tipLabel);
    topLayout->addLayout(topLayoutBtn);

    tickLineEdit = new QLineEditEx;
    QVBoxLayout* bottomLayout = new QVBoxLayout;
    bottomLayout->addLayout(topLayout);
    bottomLayout->addWidget(tickLineEdit);

    setLayout(bottomLayout);

    tickLineEdit->setReadOnly(true);
    startBtn->setEnabled(false);
    pauseBtn->setEnabled(true);
    tickLineEdit->setText(" Congratulations, You win the world cup...   ");

    connect(startBtn, SIGNAL(clicked()),this, SLOT(startBtnclicked()));
    connect(pauseBtn, SIGNAL(clicked()),this, SLOT(pauseBtnclicked()));
}

EventManageDialog::~EventManageDialog()
{
    delete ui;
}

void EventManageDialog::startBtnclicked()
{
    tickLineEdit->setVisible(true);
    startBtn->setEnabled(false);
    pauseBtn->setEnabled(true);
}

void EventManageDialog::pauseBtnclicked()
{
    tickLineEdit->killTimer(tickLineEdit->timerId);
    tickLineEdit->timerId = 0;
    startBtn->setEnabled(true);
    pauseBtn->setEnabled(false);
    tickLineEdit->setVisible(false);
}
