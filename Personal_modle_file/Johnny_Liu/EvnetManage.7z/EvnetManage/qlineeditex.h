#ifndef QLINEEDITEX_H
#define QLINEEDITEX_H

#include <QLineEdit>
#include <QWidget>

class QLineEditEx : public QLineEdit
{
Q_OBJECT
public:
    explicit QLineEditEx(QWidget *parent = 0);

signals:

public slots:

public:
    int     timerId;
    void    setText(const QString &inText);
    QString getText() const {return tipText;}

private:
    QString tipText;
    int     offset;

protected:
    void paintEvent(QPaintEvent *event);
    void timerEvent(QTimerEvent *event);
    void showEvent(QShowEvent *event);
};

#endif // QLINEEDITEX_H
