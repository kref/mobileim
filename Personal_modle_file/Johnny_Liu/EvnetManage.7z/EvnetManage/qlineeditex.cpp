#include "qlineeditex.h"
#include <QtGui>

QLineEditEx::QLineEditEx(QWidget *parent) :
    QLineEdit(parent)
{
    offset = 0;
    timerId = 0;
}

void QLineEditEx::setText(const QString &inText)
{
    tipText = inText;
    update();
    updateGeometry();
}

void QLineEditEx::paintEvent(QPaintEvent * /* event */)
{
    QPainter painter(this);

    int textWidth = fontMetrics().width(getText());
    if (textWidth < 1)
        return;
    int x = -offset;
    while (x < width())
    {
        painter.drawText(x, 0, textWidth, height(),
                         Qt::AlignLeft | Qt::AlignVCenter, getText());
        x += textWidth;
    }
}

void QLineEditEx::showEvent(QShowEvent * /* event */)
{
    timerId = startTimer(30);
}

void QLineEditEx::timerEvent(QTimerEvent *event)
{
    if (event->timerId() == timerId)
    {
        ++offset;
        if (offset >= fontMetrics().width(getText()))
            offset = 0;
        scroll(-1, 0);

    }
    else
    {
        QWidget::timerEvent(event);
    }
}
