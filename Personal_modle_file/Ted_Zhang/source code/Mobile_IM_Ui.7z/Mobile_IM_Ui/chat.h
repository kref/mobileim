#ifndef CHAT_H
#define CHAT_H

#include <QDialog>
#include "ui_Chat.h"
//#include "Mobile_IM_Ui.h"
//class Mobile_IM_Ui;
class Chat : public QDialog, public Ui::Chat
	{
		Q_OBJECT
	public:
		Chat(QWidget *parent = 0);
//	public slots:
		
	};
#endif
