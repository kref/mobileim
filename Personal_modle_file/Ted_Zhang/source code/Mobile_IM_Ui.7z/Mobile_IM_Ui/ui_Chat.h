/********************************************************************************
** Form generated from reading UI file 'Chat.ui'
**
** Created: Mon Jun 21 15:59:50 2010
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHAT_H
#define UI_CHAT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Chat
{
public:
    QLabel *label_2;
    QPushButton *sendButton;
    QPushButton *closeButton;
    QLabel *label;
    QPlainTextEdit *plainTextEdit;
    QPlainTextEdit *plainTextEdit_2;

    void setupUi(QDialog *Chat)
    {
        if (Chat->objectName().isEmpty())
            Chat->setObjectName(QString::fromUtf8("Chat"));
        Chat->resize(360, 320);
        label_2 = new QLabel(Chat);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 0, 81, 81));
        QFont font;
        font.setPointSize(8);
        font.setUnderline(false);
        font.setKerning(true);
        font.setStyleStrategy(QFont::PreferDefault);
        label_2->setFont(font);
        label_2->setPixmap(QPixmap(QString::fromUtf8(":/qq/picture.jpg")));
        sendButton = new QPushButton(Chat);
        sendButton->setObjectName(QString::fromUtf8("sendButton"));
        sendButton->setGeometry(QRect(220, 290, 61, 23));
        QFont font1;
        font1.setPointSize(6);
        sendButton->setFont(font1);
        sendButton->setAutoDefault(false);
        sendButton->setDefault(true);
        sendButton->setFlat(false);
        closeButton = new QPushButton(Chat);
        closeButton->setObjectName(QString::fromUtf8("closeButton"));
        closeButton->setGeometry(QRect(290, 290, 61, 23));
        closeButton->setFont(font1);
        label = new QLabel(Chat);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 30, 141, 31));
        QFont font2;
        font2.setFamily(QString::fromUtf8("MS Shell Dlg 2"));
        font2.setPointSize(7);
        label->setFont(font2);
        label->setTextFormat(Qt::AutoText);
        plainTextEdit = new QPlainTextEdit(Chat);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        plainTextEdit->setGeometry(QRect(10, 90, 341, 121));
        plainTextEdit_2 = new QPlainTextEdit(Chat);
        plainTextEdit_2->setObjectName(QString::fromUtf8("plainTextEdit_2"));
        plainTextEdit_2->setGeometry(QRect(10, 230, 341, 51));

        retranslateUi(Chat);

        QMetaObject::connectSlotsByName(Chat);
    } // setupUi

    void retranslateUi(QDialog *Chat)
    {
        Chat->setWindowTitle(QApplication::translate("Chat", "Chating", 0, QApplication::UnicodeUTF8));
        label_2->setText(QString());
        sendButton->setText(QApplication::translate("Chat", "\345\217\221\351\200\201", 0, QApplication::UnicodeUTF8));
        closeButton->setText(QApplication::translate("Chat", "\345\205\263\351\227\255", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Chat", "\345\245\275\345\217\213\347\232\204\344\270\252\346\200\247\347\255\276\345\220\215", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Chat: public Ui_Chat {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHAT_H
