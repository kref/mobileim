#include <QtGui>
#include "chat.h"

Chat::Chat(QWidget *parent) : QDialog(parent)
	{
		setupUi(this);
		
		QObject::connect(closeButton, SIGNAL(clicked()),
						 this, SLOT(close()));
		
	}
