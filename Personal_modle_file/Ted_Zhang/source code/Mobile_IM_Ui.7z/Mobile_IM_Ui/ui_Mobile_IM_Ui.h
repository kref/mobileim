/********************************************************************************
** Form generated from reading UI file 'Mobile_IM_Ui.ui'
**
** Created: Fri Jun 18 14:53:04 2010
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MOBILE_IM_UI_H
#define UI_MOBILE_IM_UI_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QToolButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Mobile_IM_Ui
{
public:
    QPushButton *pushButton;
    QToolButton *toolButton_3;
    QToolButton *toolButton_4;
    QToolButton *toolButton;
    QToolButton *toolButton_2;
    QToolButton *toolButton_5;
    QWidget *widget;
    QLabel *label_2;
    QLabel *label;
    QComboBox *comboBox;
    QLabel *label_3;
    QPushButton *chatButton;
    QPushButton *pushButton_2;

    void setupUi(QWidget *Mobile_IM_Ui)
    {
        if (Mobile_IM_Ui->objectName().isEmpty())
            Mobile_IM_Ui->setObjectName(QString::fromUtf8("Mobile_IM_Ui"));
        Mobile_IM_Ui->resize(360, 312);
        pushButton = new QPushButton(Mobile_IM_Ui);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(0, 100, 120, 41));
        QFont font;
        font.setPointSize(7);
        pushButton->setFont(font);
        toolButton_3 = new QToolButton(Mobile_IM_Ui);
        toolButton_3->setObjectName(QString::fromUtf8("toolButton_3"));
        toolButton_3->setGeometry(QRect(0, 210, 360, 31));
        toolButton_3->setFont(font);
        toolButton_3->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        toolButton_3->setAutoRaise(true);
        toolButton_3->setArrowType(Qt::RightArrow);
        toolButton_4 = new QToolButton(Mobile_IM_Ui);
        toolButton_4->setObjectName(QString::fromUtf8("toolButton_4"));
        toolButton_4->setGeometry(QRect(0, 240, 360, 31));
        toolButton_4->setFont(font);
        toolButton_4->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        toolButton_4->setAutoRaise(true);
        toolButton_4->setArrowType(Qt::RightArrow);
        toolButton = new QToolButton(Mobile_IM_Ui);
        toolButton->setObjectName(QString::fromUtf8("toolButton"));
        toolButton->setGeometry(QRect(0, 150, 360, 31));
        toolButton->setFont(font);
        toolButton->setAutoFillBackground(false);
        toolButton->setPopupMode(QToolButton::DelayedPopup);
        toolButton->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        toolButton->setAutoRaise(true);
        toolButton->setArrowType(Qt::RightArrow);
        toolButton_2 = new QToolButton(Mobile_IM_Ui);
        toolButton_2->setObjectName(QString::fromUtf8("toolButton_2"));
        toolButton_2->setGeometry(QRect(0, 180, 360, 31));
        toolButton_2->setFont(font);
        toolButton_2->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        toolButton_2->setAutoRaise(true);
        toolButton_2->setArrowType(Qt::RightArrow);
        toolButton_5 = new QToolButton(Mobile_IM_Ui);
        toolButton_5->setObjectName(QString::fromUtf8("toolButton_5"));
        toolButton_5->setGeometry(QRect(0, 270, 360, 31));
        toolButton_5->setFont(font);
        toolButton_5->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        toolButton_5->setAutoRaise(true);
        toolButton_5->setArrowType(Qt::RightArrow);
        widget = new QWidget(Mobile_IM_Ui);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 10, 360, 91));
        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 0, 91, 81));
        QFont font1;
        font1.setPointSize(8);
        font1.setUnderline(false);
        font1.setKerning(true);
        font1.setStyleStrategy(QFont::PreferDefault);
        label_2->setFont(font1);
        label_2->setPixmap(QPixmap(QString::fromUtf8(":/qq/picture.jpg")));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 50, 141, 31));
        QFont font2;
        font2.setFamily(QString::fromUtf8("MS Shell Dlg 2"));
        font2.setPointSize(6);
        label->setFont(font2);
        label->setTextFormat(Qt::AutoText);
        comboBox = new QComboBox(widget);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(220, 10, 111, 31));
        comboBox->setFont(font2);
        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(110, 10, 101, 31));
        label_3->setFont(font2);
        label_3->setTextFormat(Qt::AutoText);
        chatButton = new QPushButton(Mobile_IM_Ui);
        chatButton->setObjectName(QString::fromUtf8("chatButton"));
        chatButton->setGeometry(QRect(240, 100, 120, 41));
        chatButton->setFont(font);
        pushButton_2 = new QPushButton(Mobile_IM_Ui);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(120, 100, 120, 41));
        pushButton_2->setFont(font);

        retranslateUi(Mobile_IM_Ui);

        QMetaObject::connectSlotsByName(Mobile_IM_Ui);
    } // setupUi

    void retranslateUi(QWidget *Mobile_IM_Ui)
    {
        Mobile_IM_Ui->setWindowTitle(QApplication::translate("Mobile_IM_Ui", "Mobile_IM_Ui", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("Mobile_IM_Ui", "\345\245\275\345\217\213", 0, QApplication::UnicodeUTF8));
        toolButton_3->setText(QApplication::translate("Mobile_IM_Ui", "\345\205\254\345\217\270\345\220\214\344\272\213", 0, QApplication::UnicodeUTF8));
        toolButton_4->setText(QApplication::translate("Mobile_IM_Ui", "\345\244\247\345\255\246\345\220\214\345\255\246", 0, QApplication::UnicodeUTF8));
        toolButton->setText(QApplication::translate("Mobile_IM_Ui", "\346\210\221\347\232\204\345\245\275\345\217\213", 0, QApplication::UnicodeUTF8));
        toolButton_2->setText(QApplication::translate("Mobile_IM_Ui", "\346\210\221\347\232\204\345\256\266\344\272\272", 0, QApplication::UnicodeUTF8));
        toolButton_5->setText(QApplication::translate("Mobile_IM_Ui", "\351\231\214\347\224\237\344\272\272", 0, QApplication::UnicodeUTF8));
        label_2->setText(QString());
        label->setText(QApplication::translate("Mobile_IM_Ui", "\344\270\252\346\200\247\347\255\276\345\220\215", 0, QApplication::UnicodeUTF8));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("Mobile_IM_Ui", "[\345\234\250\347\272\277]", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Mobile_IM_Ui", "[\345\277\231\347\242\214]", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Mobile_IM_Ui", "[Q\346\210\221]", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Mobile_IM_Ui", "[\351\232\220\350\272\253]", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Mobile_IM_Ui", "[\347\246\273\347\272\277]", 0, QApplication::UnicodeUTF8)
        );
        label_3->setText(QApplication::translate("Mobile_IM_Ui", "\346\230\265\347\247\260", 0, QApplication::UnicodeUTF8));
        chatButton->setText(QApplication::translate("Mobile_IM_Ui", "\346\255\243\345\234\250\350\201\212\345\244\251", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("Mobile_IM_Ui", "\347\276\244/\350\256\250\350\256\272\347\273\204", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Mobile_IM_Ui: public Ui_Mobile_IM_Ui {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MOBILE_IM_UI_H
