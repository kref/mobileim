/********************************************************************************
** Form generated from reading UI file 'imclient.ui'
**
** Created: Mon Jul 12 12:28:21 2010
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_IMCLIENT_H
#define UI_IMCLIENT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QTextBrowser>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ImClient
{
public:
    QWidget *centralwidget;
    QPushButton *puBtnSearch;
    QLabel *lblStatus;
    QTextBrowser *txtBrChatHistory;
    QTextBrowser *txtBrContacts;
    QPushButton *puBtnSendMsg;
    QLineEdit *lineEditSendingMsg;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *ImClient)
    {
        if (ImClient->objectName().isEmpty())
            ImClient->setObjectName(QString::fromUtf8("ImClient"));
        ImClient->resize(800, 600);
        centralwidget = new QWidget(ImClient);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        puBtnSearch = new QPushButton(centralwidget);
        puBtnSearch->setObjectName(QString::fromUtf8("puBtnSearch"));
        puBtnSearch->setGeometry(QRect(20, 10, 91, 31));
        lblStatus = new QLabel(centralwidget);
        lblStatus->setObjectName(QString::fromUtf8("lblStatus"));
        lblStatus->setGeometry(QRect(130, 10, 181, 31));
        txtBrChatHistory = new QTextBrowser(centralwidget);
        txtBrChatHistory->setObjectName(QString::fromUtf8("txtBrChatHistory"));
        txtBrChatHistory->setGeometry(QRect(20, 120, 291, 141));
        txtBrContacts = new QTextBrowser(centralwidget);
        txtBrContacts->setObjectName(QString::fromUtf8("txtBrContacts"));
        txtBrContacts->setGeometry(QRect(20, 50, 291, 61));
        puBtnSendMsg = new QPushButton(centralwidget);
        puBtnSendMsg->setObjectName(QString::fromUtf8("puBtnSendMsg"));
        puBtnSendMsg->setGeometry(QRect(240, 280, 75, 31));
        lineEditSendingMsg = new QLineEdit(centralwidget);
        lineEditSendingMsg->setObjectName(QString::fromUtf8("lineEditSendingMsg"));
        lineEditSendingMsg->setGeometry(QRect(20, 270, 211, 51));
        ImClient->setCentralWidget(centralwidget);
        menubar = new QMenuBar(ImClient);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        ImClient->setMenuBar(menubar);
        statusbar = new QStatusBar(ImClient);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        ImClient->setStatusBar(statusbar);

        retranslateUi(ImClient);

        QMetaObject::connectSlotsByName(ImClient);
    } // setupUi

    void retranslateUi(QMainWindow *ImClient)
    {
        ImClient->setWindowTitle(QApplication::translate("ImClient", "imclient", 0, QApplication::UnicodeUTF8));
        puBtnSearch->setText(QApplication::translate("ImClient", "Log in", 0, QApplication::UnicodeUTF8));
        lblStatus->setText(QApplication::translate("ImClient", "Current: Offline", 0, QApplication::UnicodeUTF8));
        puBtnSendMsg->setText(QApplication::translate("ImClient", "Send", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ImClient: public Ui_ImClient {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_IMCLIENT_H
