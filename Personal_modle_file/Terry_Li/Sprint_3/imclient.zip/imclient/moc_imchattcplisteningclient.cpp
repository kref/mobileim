/****************************************************************************
** Meta object code from reading C++ file 'imchattcplisteningclient.h'
**
** Created: Mon Jul 12 12:28:19 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "imchattcplisteningclient.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'imchattcplisteningclient.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ImChatTcpListeningClient[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      34,   26,   25,   25, 0x05,

 // slots: signature, parameters, type, tag, flags
      52,   25,   25,   25, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_ImChatTcpListeningClient[] = {
    "ImChatTcpListeningClient\0\0message\0"
    "readData(QString)\0readClient()\0"
};

const QMetaObject ImChatTcpListeningClient::staticMetaObject = {
    { &QTcpSocket::staticMetaObject, qt_meta_stringdata_ImChatTcpListeningClient,
      qt_meta_data_ImChatTcpListeningClient, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ImChatTcpListeningClient::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ImChatTcpListeningClient::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ImChatTcpListeningClient::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ImChatTcpListeningClient))
        return static_cast<void*>(const_cast< ImChatTcpListeningClient*>(this));
    return QTcpSocket::qt_metacast(_clname);
}

int ImChatTcpListeningClient::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTcpSocket::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: readData((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: readClient(); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void ImChatTcpListeningClient::readData(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
