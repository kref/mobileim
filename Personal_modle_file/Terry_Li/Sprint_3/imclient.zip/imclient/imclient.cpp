/****************************************************************************
**
** Trolltech hereby grants a license to use the Qt/Eclipse Integration
** plug-in (the software contained herein), in binary form, solely for the
** purpose of creating code to be used with Trolltech's Qt software.
**
** Qt Designer is licensed under the terms of the GNU General Public
** License versions 2.0 and 3.0 ("GPL License"). Trolltech offers users the
** right to use certain no GPL licensed software under the terms of its GPL
** Exception version 1.2 (http://trolltech.com/products/qt/gplexception).
**
** THIS SOFTWARE IS PROVIDED BY TROLLTECH AND ITS CONTRIBUTORS (IF ANY) "AS
** IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
** TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
** PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
** OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
** EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
** PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
** PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
** LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
** NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
** SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** Since we now have the GPL exception I think that the "special exception
** is no longer needed. The license text proposed above (other than the
** special exception portion of it) is the BSD license and we have added
** the BSD license as a permissible license under the exception.
**
****************************************************************************/

#include <QMessageBox>

#include "imclient.h"

ImClient::ImClient(QWidget *parent)
    : QMainWindow(parent)
{
	ui.setupUi(this);
	m_imLoginTcp = new ImLoginTcp();
	
	//Will creeate Conversations with Array for every chat
	m_tcpConversation1 = new ImChatTcp();		
	
	// For listening connection from other client 
	m_tcpConversationListening1 =  new ImChatTcpListening();		
	connect(m_tcpConversationListening1, SIGNAL(notfiyReceiveData(QString)), this, SLOT(recieveMessage(QString)));
		
	connect(m_imLoginTcp, SIGNAL(connected()), this, SLOT(updateStatus()));
	connect(m_imLoginTcp, SIGNAL(disconnected()), this, SLOT(updateStatus()));
	connect(m_imLoginTcp, SIGNAL(connectError(QString)), this, SLOT(showError(QString)));
	connect(m_imLoginTcp, SIGNAL(readData(QString)), this, SLOT(recieveServerData(QString)));		
	connect(ui.puBtnSearch, SIGNAL(clicked()), this, SLOT(connectToServer()));	

	connect(ui.puBtnSendMsg, SIGNAL(clicked()), this, SLOT(sendMessage()));	
	//connect(m_tcpConversation1, SIGNAL(connected()), this, SLOT(xxx()));
	//connect(m_tcpConversation1, SIGNAL(disconnected()), this, SLOT(xxx()));
	connect(m_tcpConversation1, SIGNAL(connectError(QString)), this, SLOT(showError(QString)));
	connect(m_tcpConversation1, SIGNAL(readMessage(QString)), this, SLOT(recieveMessage(QString)));		
		
	updateStatus();
}

ImClient::~ImClient()
{    
    if (m_imLoginTcp){
    delete m_imLoginTcp;
    m_imLoginTcp = NULL;
    }
    disconnect(m_imLoginTcp, SIGNAL(connected()), this, SLOT(updateStatus()));
    if (m_tcpConversation1){
    delete m_tcpConversation1;
    m_tcpConversation1 = NULL;
    }
    
    if (m_tcpConversationListening1){
    delete m_tcpConversationListening1;
    m_tcpConversationListening1 = NULL;
    }
}

// For login
void ImClient::connectToServer()
	{
	m_imLoginTcp->connectToHost();
	}

// Update status in client when login successfully
void ImClient::updateStatus()
	{
	if (m_imLoginTcp->isConnnected()) {
	ui.puBtnSearch->setEnabled(false);
	ui.puBtnSendMsg->setEnabled(true);
	ui.lblStatus->setText(tr("Current: Online"));	
	//startListeningClient();
	} else {
	ui.puBtnSearch->setEnabled(true);
	ui.puBtnSendMsg->setEnabled(false);
	ui.lblStatus->setText(tr("Current: Offline"));	
	}		
	}

// Recieve data from server.
void ImClient::recieveServerData(const QString &message)
	{
	if ( true ){ // If this is contacts information, call updateContactsInfo();
	updateContactsInfo(message); 
	updateChatHistory(message);// For testing
	}	
	}

// Update contacts info in client when login successfully and 
// get other contacts info from server.
void ImClient::updateContactsInfo(const QString &message)
	{
	if (m_imLoginTcp->isConnnected()){
	//update contacts information
	}
	}

// For connecting peer client
void ImClient::connectToClient(const QString &ip)
	{	
	if (!m_tcpConversation1->isConnnected())
	    m_tcpConversation1->connectToClient(ip);
	}

// For chating
void ImClient::recieveMessage(const QString &message)
	{
	updateChatHistory(message);
	}

// For chating
void ImClient::sendMessage()
	{
	connectToClient(); // If connect successfully, continue
	if (m_tcpConversation1->isConnnected()){
	QString message = ui.lineEditSendingMsg->text();
	m_tcpConversation1->sendMessage(message);
	updateChatHistory(message);	
	ui.lineEditSendingMsg->clear(); // Clear the message in text eidit
	}
	}

// For chating
void ImClient::updateChatHistory(const QString &message)
	{
	ui.txtBrChatHistory->append(message);
	}

void ImClient::showError(const QString &error)
	{
	updateChatHistory(error);
	QMessageBox warningBox;		
	warningBox.setText(error);
	warningBox.setStandardButtons(QMessageBox::Ok);	
	//Modal dialog
	int ret = warningBox.exec(); // or use Non-Modal dialog: warningBox.show();	
	}
