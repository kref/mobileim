/****************************************************************************
** Meta object code from reading C++ file 'tcpsocketclient.h'
**
** Created: Sat Jun 26 15:59:17 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "tcpsocketclient.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tcpsocketclient.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_TcpSocketClient[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: signature, parameters, type, tag, flags
      17,   16,   16,   16, 0x05,
      40,   29,   16,   16, 0x05,
      62,   16,   16,   16, 0x05,
      85,   77,   16,   16, 0x05,

 // slots: signature, parameters, type, tag, flags
     106,   16,   16,   16, 0x0a,
     124,   29,   16,   16, 0x0a,
     152,   16,   16,   16, 0x0a,
     173,   16,   16,   16, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_TcpSocketClient[] = {
    "TcpSocketClient\0\0connected()\0connectErr\0"
    "connectError(QString)\0disconnected()\0"
    "message\0readMessage(QString)\0"
    "notifyConnected()\0notifyConnectError(QString)\0"
    "notifyDisconnected()\0notifyReadMessage()\0"
};

const QMetaObject TcpSocketClient::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_TcpSocketClient,
      qt_meta_data_TcpSocketClient, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &TcpSocketClient::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *TcpSocketClient::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *TcpSocketClient::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_TcpSocketClient))
        return static_cast<void*>(const_cast< TcpSocketClient*>(this));
    return QObject::qt_metacast(_clname);
}

int TcpSocketClient::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: connected(); break;
        case 1: connectError((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: disconnected(); break;
        case 3: readMessage((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: notifyConnected(); break;
        case 5: notifyConnectError((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: notifyDisconnected(); break;
        case 7: notifyReadMessage(); break;
        default: ;
        }
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void TcpSocketClient::connected()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void TcpSocketClient::connectError(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void TcpSocketClient::disconnected()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void TcpSocketClient::readMessage(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_END_MOC_NAMESPACE
