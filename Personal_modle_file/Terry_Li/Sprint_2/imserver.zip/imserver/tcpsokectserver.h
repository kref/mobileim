/*
 * tcpsokectserver.h
 *
 *  Created on: 2010-6-26
 *      Author: Terry.Li
 */

#ifndef TCPSOKECTSERVER_H_
#define TCPSOKECTSERVER_H_

#include <QTcpServer>

class TcpSokectServer : public QTcpServer
	{
	Q_OBJECT
	
public:
	TcpSokectServer(QObject *parent = 0);
	virtual ~TcpSokectServer();
	
void incomingConnection(int socketId);
	};

#endif /* TCPSOKECTSERVER_H_ */
