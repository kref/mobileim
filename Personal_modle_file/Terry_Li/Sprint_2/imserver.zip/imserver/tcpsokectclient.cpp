/*
 * tcpsokectclient.cpp
 *
 *  Created on: 2010-6-26
 *      Author: Terry.Li
 */

#include "tcpsokectclient.h"

TcpSokectClient::TcpSokectClient(QObject *parent) : 
QTcpSocket(parent)
	{
    connect(this, SIGNAL(readyRead()), this, SLOT(readClient()));
    connect(this, SIGNAL(disconnected()), this, SLOT(deleteLater()));
	}

TcpSokectClient::~TcpSokectClient()
	{
	// TODO Auto-generated destructor stub
	}

void TcpSokectClient::replyClient() // Reply client with other client information(ip and port)
	{
	QString message = tr("This message is from Service");
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_4_7);
    out << quint16(0) << quint8('M') << message;

    out.device()->seek(0);
    out << quint16(block.size() - sizeof(quint16));    
    write(block); 
	}
	
void TcpSokectClient::readClient()    //Read ip and port of client and store them on server
	{
    QDataStream in(this);
    in.setVersion(QDataStream::Qt_4_7);

    if (bytesAvailable() < sizeof(quint16))
        return;
    
    quint16 blockSize;
    in >> blockSize;
    if (bytesAvailable() < blockSize)
        return;

    quint8 requestType;
    QString messageFromClient;

    in >> requestType;
    if ( requestType == 'M' ) {
    in >> messageFromClient;    
    replyClient();
    }
	}
    
