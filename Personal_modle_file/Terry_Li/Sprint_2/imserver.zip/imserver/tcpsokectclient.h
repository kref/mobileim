/*
 * tcpsokectclient.h
 *
 *  Created on: 2010-6-26
 *      Author: Terry.Li
 */

#ifndef TCPSOKECTCLIENT_H_
#define TCPSOKECTCLIENT_H_

#include <QTcpSocket>

class TcpSokectClient : public QTcpSocket
	{
	Q_OBJECT
	
public:
	TcpSokectClient(QObject *parent = 0);
	virtual ~TcpSokectClient();

public: // New function
	void replyClient(); // Reply client with other client information(ip and port)
	
public slots:
    void readClient();    //Read ip and port of client and store them on server
	};

#endif /* TCPSOKECTCLIENT_H_ */
