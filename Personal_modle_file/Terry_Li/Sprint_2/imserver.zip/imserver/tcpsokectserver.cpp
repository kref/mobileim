/*
 * tcpsokectserver.cpp
 *
 *  Created on: 2010-6-26
 *      Author: Terry.Li
 */

#include "tcpsokectserver.h"
#include "tcpsokectclient.h"

TcpSokectServer::TcpSokectServer(QObject *parent) :
QTcpServer(parent)
	{
	
	}

TcpSokectServer::~TcpSokectServer()
	{
	
	}

void TcpSokectServer::incomingConnection(int socketId)
	{
	TcpSokectClient *socket = new TcpSokectClient(this);
    socket->setSocketDescriptor(socketId);    
	}
