/*
 * Server.cpp
 *
 *  Created on: Jun 8, 2010
 *      Author: cninteli
 */

#include "clientsocket.h"
#include "Server.h"

Server::Server(QObject *parent):
QTcpServer(parent)
	{
	qDebug("Im=>Server::Server");
	// TODO Auto-generated constructor stub
	qDebug("Im<=Server::Server");
	}

Server::~Server()
	{
	qDebug("Im=>Server::~Server");
	// TODO Auto-generated destructor stub
	qDebug("Im<=Server::~Server");
	}

void Server::incomingConnection(int socketId)
	{
	qDebug("Im=>Server::incomingConnection");
    ClientSocket *socket = new ClientSocket(this);
    socket->setSocketDescriptor(socketId);    
    qDebug("Im<=Server::incomingConnection");
	}
