/********************************************************************************
** Form generated from reading UI file 'IMSocketClient.ui'
**
** Created: Sat Jun 12 18:19:32 2010
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_IMSOCKETCLIENT_H
#define UI_IMSOCKETCLIENT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_IMSocketClient
{
public:
    QLabel *label_2;
    QLineEdit *sendMessageLE;
    QLabel *label_3;
    QLineEdit *portLE;
    QPushButton *sendButton;
    QLabel *label;
    QLineEdit *hostNameLE;
    QPushButton *connectButton;
    QLabel *label_4;
    QPushButton *exitButton;
    QLabel *statusLabel;
    QTextBrowser *chatRecordBrowser;

    void setupUi(QDialog *IMSocketClient)
    {
        if (IMSocketClient->objectName().isEmpty())
            IMSocketClient->setObjectName(QString::fromUtf8("IMSocketClient"));
        IMSocketClient->resize(400, 408);
        label_2 = new QLabel(IMSocketClient);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 60, 61, 31));
        sendMessageLE = new QLineEdit(IMSocketClient);
        sendMessageLE->setObjectName(QString::fromUtf8("sendMessageLE"));
        sendMessageLE->setGeometry(QRect(90, 300, 291, 20));
        label_3 = new QLabel(IMSocketClient);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 300, 61, 21));
        portLE = new QLineEdit(IMSocketClient);
        portLE->setObjectName(QString::fromUtf8("portLE"));
        portLE->setGeometry(QRect(130, 60, 161, 20));
        sendButton = new QPushButton(IMSocketClient);
        sendButton->setObjectName(QString::fromUtf8("sendButton"));
        sendButton->setGeometry(QRect(310, 333, 71, 20));
        label = new QLabel(IMSocketClient);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 10, 111, 41));
        hostNameLE = new QLineEdit(IMSocketClient);
        hostNameLE->setObjectName(QString::fromUtf8("hostNameLE"));
        hostNameLE->setGeometry(QRect(130, 20, 161, 20));
        connectButton = new QPushButton(IMSocketClient);
        connectButton->setObjectName(QString::fromUtf8("connectButton"));
        connectButton->setGeometry(QRect(130, 100, 161, 23));
        label_4 = new QLabel(IMSocketClient);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(20, 120, 111, 21));
        exitButton = new QPushButton(IMSocketClient);
        exitButton->setObjectName(QString::fromUtf8("exitButton"));
        exitButton->setGeometry(QRect(310, 370, 75, 23));
        statusLabel = new QLabel(IMSocketClient);
        statusLabel->setObjectName(QString::fromUtf8("statusLabel"));
        statusLabel->setGeometry(QRect(10, 350, 271, 31));
        chatRecordBrowser = new QTextBrowser(IMSocketClient);
        chatRecordBrowser->setObjectName(QString::fromUtf8("chatRecordBrowser"));
        chatRecordBrowser->setGeometry(QRect(90, 150, 291, 141));

        retranslateUi(IMSocketClient);

        QMetaObject::connectSlotsByName(IMSocketClient);
    } // setupUi

    void retranslateUi(QDialog *IMSocketClient)
    {
        IMSocketClient->setWindowTitle(QApplication::translate("IMSocketClient", "IMSocketClient", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("IMSocketClient", "Port", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("IMSocketClient", "Input", 0, QApplication::UnicodeUTF8));
        portLE->setText(QApplication::translate("IMSocketClient", "6718", 0, QApplication::UnicodeUTF8));
        sendButton->setText(QApplication::translate("IMSocketClient", "Send", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("IMSocketClient", "Host Name", 0, QApplication::UnicodeUTF8));
        hostNameLE->setText(QApplication::translate("IMSocketClient", "Local Host", 0, QApplication::UnicodeUTF8));
        connectButton->setText(QApplication::translate("IMSocketClient", "Connect to Host", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("IMSocketClient", "Chat record:", 0, QApplication::UnicodeUTF8));
        exitButton->setText(QApplication::translate("IMSocketClient", "Exit", 0, QApplication::UnicodeUTF8));
        statusLabel->setText(QApplication::translate("IMSocketClient", "No connecting", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class IMSocketClient: public Ui_IMSocketClient {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_IMSOCKETCLIENT_H
