#include <QtGui>
#include <QApplication>

#include "IMSocketClient.h"

int main(int argc, char *argv[])
{
	qDebug("Im<=>IMSocketClient:main()");
    QApplication a(argc, argv);
    IMSocketClient w;
    w.showMaximized();
    return a.exec();
}
