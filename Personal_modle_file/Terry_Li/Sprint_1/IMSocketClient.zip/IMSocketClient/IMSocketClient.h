#ifndef IMSOCKETCLIENT_H
#define IMSOCKETCLIENT_H

#include <QDialog>
#include <QTcpSocket>

#include "ui_IMSocketClient.h"

class IMSocketClient : public QDialog
{
    Q_OBJECT

public:
	IMSocketClient(QWidget *parent = 0);
    ~IMSocketClient();

private slots:
    void connectToServer();
    void sendRequest();
    void updateStatus();
    void error();
    void connectionClosedByServer();
    void receiveDataFromServer();

private:
    void upatedChatRecord(QString chatMessage);
    void closeConnection();
    
private:
    Ui_IMSocketClient *ui;
    QTcpSocket tcpSocket;    
};

#endif // IMSOCKETCLIENT_H
