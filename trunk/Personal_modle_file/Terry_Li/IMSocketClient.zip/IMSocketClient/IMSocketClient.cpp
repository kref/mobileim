#include <QtNetwork/QHostAddress>
#include <QtNetwork/QAbstractSocket>
#include <qdebug.h>

#include "IMSocketClient.h"


IMSocketClient::IMSocketClient(QWidget *parent)
    : QDialog(parent)
{
    qDebug("Im=>IMSocketClient::IMSocketClient");
	ui = new Ui_IMSocketClient;
	ui->setupUi(this);
	
	ui->connectButton->setEnabled(true);
	ui->sendButton->setEnabled(false);
	
    connect(ui->connectButton, SIGNAL(clicked()), this, SLOT(connectToServer()));    
    
    connect(&tcpSocket, SIGNAL(connected()), this, SLOT(updateStatus()));
    connect(&tcpSocket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(error()));
    connect(&tcpSocket, SIGNAL(disconnected()), this, SLOT(connectionClosedByServer()));
    connect(&tcpSocket, SIGNAL(readyRead()), this, SLOT(receiveDataFromServer()));
    
    connect(ui->sendButton, SIGNAL(clicked()), this, SLOT(sendRequest()));
    connect(ui->exitButton, SIGNAL(clicked()), this, SLOT(reject()));
    qDebug("Im<=IMSocketClient::IMSocketClient");
}

IMSocketClient::~IMSocketClient()
{
	qDebug("Im=>IMSocketClient::~IMSocketClient");
    tcpSocket.close();
    qDebug("Im<=IMSocketClient::~IMSocketClient");
}

void IMSocketClient::connectToServer()
{
	qDebug("Im=>IMSocketClient::connectToServer");
	nextBlockSize = 0;
	if(tcpSocket.isValid())
		tcpSocket.close();
	tcpSocket.connectToHost(QHostAddress::LocalHost, 6178);	
	ui->statusLabel->setText(tr("Connecting"));	    
	ui->connectButton->setEnabled(false);
	qDebug("Im<=IMSocketClient::connectToServer");
}

void IMSocketClient::updateStatus()
{
	qDebug("Im=>IMSocketClient::updateStatus");
	ui->statusLabel->setText(tr("Connected"));	 
	ui->connectButton->setEnabled(false);
	ui->sendButton->setEnabled(true);
	qDebug("Im<=IMSocketClient::updateStatus");
}

void IMSocketClient::error()
{
	qDebug("Im=>IMSocketClient::error");
	ui->connectButton->setEnabled(true);
	ui->statusLabel->setText(tcpSocket.errorString());
	closeConnection();
	qDebug("Im<=IMSocketClient::error");
}

void IMSocketClient::sendRequest()
{  
	qDebug("Im=>IMSocketClient::sendRequest");
	connectToServer(); // Why cannot get the answer from server since secondary send request?
	ui->statusLabel->setText(tr("Sending message"));
	
	QString message = ui->sendMessageLE->text();
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_4_7);
    out << quint16(0) << quint8('S') << message;

    out.device()->seek(0);
    out << quint16(block.size() - sizeof(quint16));
    tcpSocket.write(block);
	
	upatedChatRecord(message); // To update chat record after sending message
	ui->sendMessageLE->clear();
	qDebug("Im<=IMSocketClient::sendRequest");
}

// To update chat record after sending message and recieving message from server
void IMSocketClient::upatedChatRecord(QString chatMessage)
{
	qDebug("Im=>IMSocketClient::upatedChatRecord");
	ui->statusLabel->setText(tr("Connected"));		
	ui->chatRecordBrowser->append(chatMessage);		
	qDebug("Im<=IMSocketClient::upatedChatRecord");
}

void IMSocketClient::receiveDataFromServer()
{
	qDebug("Im=>IMSocketClient::receiveDataFromServer");
	ui->statusLabel->setText(tr("Receiving message"));
	
	QDataStream in(&tcpSocket);
	in.setVersion(QDataStream::Qt_4_7);

	forever {	        
	    if (nextBlockSize == 0) {
            if (tcpSocket.bytesAvailable() < sizeof(quint16))
            break;
            in >> nextBlockSize;
	    }

        if (nextBlockSize == 0xFFFF) {
            //closeConnection();	//We need to keep the connection because this is a chat app            
            break;
        }
        if (tcpSocket.bytesAvailable() < nextBlockSize)
            break;

        QString chatMessage;
        in >> chatMessage;	        
	       
        upatedChatRecord(chatMessage);	 
	        
        nextBlockSize = 0;
	}
	qDebug("Im<=IMSocketClient::receiveDataFromServer");
}

void IMSocketClient::connectionClosedByServer()
{
	qDebug("Im=>IMSocketClient::connectionClosedByServer");
    if (nextBlockSize != 0xFFFF)
    	ui->statusLabel->setText(tr("Error: Connection closed by server"));
	closeConnection();
	qDebug("Im<=IMSocketClient::connectionClosedByServer");
}

void IMSocketClient::closeConnection()
{
	qDebug("Im=>IMSocketClient::closeConnection");
	tcpSocket.close();
	ui->connectButton->setEnabled(true);
	ui->sendButton->setEnabled(false);
	qDebug("Im<=IMSocketClient::closeConnection");
}
