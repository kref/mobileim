//#include <QtNetwork>
#include "clientsocket.h"

ClientSocket::ClientSocket(QObject *parent)
    : QTcpSocket(parent)
{
	qDebug("Im=>ClientSocket::ClientSocket");
    connect(this, SIGNAL(readyRead()), this, SLOT(readClient()));
    connect(this, SIGNAL(disconnected()), this, SLOT(deleteLater()));

    nextBlockSize = 0;
    qDebug("Im<=ClientSocket::ClientSocket");
}

void ClientSocket::readClient()
{
	qDebug("Im=>ClientSocket::readClient");
    QDataStream in(this);
    in.setVersion(QDataStream::Qt_4_7);

    if (nextBlockSize == 0) {
        if (bytesAvailable() < sizeof(quint16))
            return;
        in >> nextBlockSize;
    }

    if (bytesAvailable() < nextBlockSize)
        return;

    quint8 requestType;
    QString messageFromClient;

    in >> requestType;
    in >> messageFromClient;
    
    // Answer client
    if (requestType == 'S') {
	QString message = tr("From Service");
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_4_7);
    out << quint16(0) << message;

    out.device()->seek(0);
    out << quint16(block.size() - sizeof(quint16));    
    write(block);    
    
    QDataStream out_end(this);
    out_end << quint16(0xFFFF);
    }    
    close(); 
    qDebug("Im<=ClientSocket::readClient");
}
