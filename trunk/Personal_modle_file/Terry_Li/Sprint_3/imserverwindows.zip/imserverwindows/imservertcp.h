/*
 * imservertcp.h
 *
 *  Created on: 2010-6-26
 *      Author: Terry.Li
 */

#ifndef IMSERVERTCP_H
#define IMSERVERTCP_H

#include <QTcpServer>

class ImServerTcp : public QTcpServer
{
    Q_OBJECT
	
public:
    ImServerTcp(QObject *parent = 0);
    virtual ~ImServerTcp();

    void incomingConnection(int socketId);
};

#endif /* IMSERVERTCP_H */
