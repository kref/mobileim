#include <QtCore/QCoreApplication>
#include "imservertcp.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    ImServerTcp imServerTcp;
    if (!imServerTcp.listen(QHostAddress::Any, 6666)) {
        qDebug("Terry imserver <> Failed to listen port");
        return 1;
    }
    return a.exec();
}
