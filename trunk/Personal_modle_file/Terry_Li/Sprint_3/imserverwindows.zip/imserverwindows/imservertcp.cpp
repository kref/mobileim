/*
 * imservertcp.cpp
 *
 *  Created on: 2010-6-26
 *      Author: Terry.Li
 */

#include <QFile>

#include "imservertcp.h"
#include "imservertcpclient.h"

ImServerTcp::ImServerTcp(QObject *parent) :
QTcpServer(parent)
{

}

ImServerTcp::~ImServerTcp()
{
	
}

void ImServerTcp::incomingConnection(int socketId)
{
    //qDebug("Terry Test qDebug");
    //qDebug()<<"Terry Test qDebug()";
    ImServerTcpClient *socket = new ImServerTcpClient(this);
    socket->setSocketDescriptor(socketId);    
    //socket->replyClient(); //Send other contacts information to the client
}
