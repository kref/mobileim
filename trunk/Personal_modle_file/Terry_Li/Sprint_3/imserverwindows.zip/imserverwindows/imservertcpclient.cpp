/*
 * imservertcpclient.cpp
 *
 *  Created on: 2010-6-26
 *      Author: Terry.Li
 */

#include "imservertcpclient.h"
#include <QHostAddress>

ImServerTcpClient::ImServerTcpClient(QObject *parent) : 
QTcpSocket(parent)
{
    connect(this, SIGNAL(readyRead()), this, SLOT(readClient()));
    connect(this, SIGNAL(disconnected()), this, SLOT(deleteLater()));
}

ImServerTcpClient::~ImServerTcpClient()
{
    // TODO Auto-generated destructor stub
}

void ImServerTcpClient::replyClient() // Reply client with other client information(ip and port)
{
    //QString message = tr("This message is from Service");
    QString message =  peerAddress().toString();
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);    
    out << quint16(0) << quint8('C') << message;

    out.device()->seek(0);
    out << quint16(block.size() - sizeof(quint16));    
    write(block);  
    flush();    
}
	
void ImServerTcpClient::readClient()    //Read ip and port of client and store them on server
{
    QDataStream in(this);    

    if (bytesAvailable() < sizeof(quint16))
        return;
    
    quint16 blockSize;
    in >> blockSize;
    if (bytesAvailable() < blockSize)
        return;

    quint8 requestType;
    QString messageFromClient;

    in >> requestType;
    if ( requestType == 'A' ) {
    in >> messageFromClient;    
    replyClient();    
    close();
    }
}
    
