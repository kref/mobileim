/*
 * imservertcpclient.h
 *
 *  Created on: 2010-6-26
 *      Author: Terry.Li
 */

#ifndef IMSERVERTCPCLIENT_H
#define IMSERVERTCPCLIENT_H

#include <QTcpSocket>

class ImServerTcpClient : public QTcpSocket
{
    Q_OBJECT
	
public:
    ImServerTcpClient(QObject *parent = 0);
    virtual ~ImServerTcpClient();

public: // New function
    void replyClient(); // Reply client with other client information(ip and port)
	
public slots:
    void readClient();    //Read ip and port of client and store them on server
};

#endif /* IMSERVERTCPCLIENT_H */
