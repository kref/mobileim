#include <QtGui>
#include "chat.h"

Chat::Chat(QWidget *parent) : QWidget(parent)
	{
	setupUi(this);
	QObject::connect(pbclose, SIGNAL(clicked()),
					 this, SLOT(close()));
	}
Chat::~Chat()
	{
	
	}
