#ifndef CHAT_H
#define CHAT_H

#include <QtGui>
#include "MobileIM.h"
#include "ui_Chat.h"

class Chat : public QWidget, public Ui::Chat
	{
		Q_OBJECT
public:
		Chat(QWidget *parent=0);
		~Chat();
//public slots:
//		void goToMainWindow();
	};
#endif
