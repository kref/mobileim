/********************************************************************************
** Form generated from reading UI file 'Chat.ui'
**
** Created: Fri Jul 23 16:40:44 2010
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHAT_H
#define UI_CHAT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTabWidget>
#include <QtGui/QToolButton>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_Chat
{
public:
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout_2;
    QToolButton *pTbtnViedoChat;
    QToolButton *pTbtnFileTransfer;
    QToolButton *pTbtnOther;
    QVBoxLayout *verticalLayout;
    QFrame *line;
    QTabWidget *pTwgtChat;
    QFrame *line_2;
    QHBoxLayout *horizontalLayout;
    QPushButton *pPbtnSend;
    QPushButton *pPbtnClose;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QDialog *Chat)
    {
        if (Chat->objectName().isEmpty())
            Chat->setObjectName(QString::fromUtf8("Chat"));
        Chat->resize(288, 451);
        Chat->setMaximumSize(QSize(16777215, 16777215));
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(130, 153, 177, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(198, 226, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(164, 189, 216, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(65, 76, 88, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(87, 102, 118, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        QBrush brush6(QColor(255, 255, 255, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush6);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        QBrush brush7(QColor(192, 204, 216, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush7);
        QBrush brush8(QColor(255, 255, 220, 255));
        brush8.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush7);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        Chat->setPalette(palette);
        gridLayout = new QGridLayout(Chat);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        pTbtnViedoChat = new QToolButton(Chat);
        pTbtnViedoChat->setObjectName(QString::fromUtf8("pTbtnViedoChat"));
        pTbtnViedoChat->setMinimumSize(QSize(40, 40));
        pTbtnViedoChat->setMaximumSize(QSize(40, 40));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/newPrefix/chat.png"), QSize(), QIcon::Normal, QIcon::Off);
        pTbtnViedoChat->setIcon(icon);
        pTbtnViedoChat->setIconSize(QSize(40, 40));
        pTbtnViedoChat->setAutoRaise(false);

        horizontalLayout_2->addWidget(pTbtnViedoChat);

        pTbtnFileTransfer = new QToolButton(Chat);
        pTbtnFileTransfer->setObjectName(QString::fromUtf8("pTbtnFileTransfer"));
        pTbtnFileTransfer->setMinimumSize(QSize(40, 40));
        pTbtnFileTransfer->setMaximumSize(QSize(40, 40));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/newPrefix/transfer.png"), QSize(), QIcon::Normal, QIcon::Off);
        pTbtnFileTransfer->setIcon(icon1);
        pTbtnFileTransfer->setIconSize(QSize(40, 40));
        pTbtnFileTransfer->setAutoRaise(true);

        horizontalLayout_2->addWidget(pTbtnFileTransfer);

        pTbtnOther = new QToolButton(Chat);
        pTbtnOther->setObjectName(QString::fromUtf8("pTbtnOther"));
        pTbtnOther->setMinimumSize(QSize(40, 40));
        pTbtnOther->setMaximumSize(QSize(40, 40));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/newPrefix/dockswap.png"), QSize(), QIcon::Normal, QIcon::Off);
        pTbtnOther->setIcon(icon2);
        pTbtnOther->setIconSize(QSize(40, 40));
        pTbtnOther->setAutoRaise(true);

        horizontalLayout_2->addWidget(pTbtnOther);


        gridLayout->addLayout(horizontalLayout_2, 0, 0, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        line = new QFrame(Chat);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line);

        pTwgtChat = new QTabWidget(Chat);
        pTwgtChat->setObjectName(QString::fromUtf8("pTwgtChat"));

        verticalLayout->addWidget(pTwgtChat);

        line_2 = new QFrame(Chat);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_2);


        gridLayout->addLayout(verticalLayout, 1, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        pPbtnSend = new QPushButton(Chat);
        pPbtnSend->setObjectName(QString::fromUtf8("pPbtnSend"));
        pPbtnSend->setMinimumSize(QSize(50, 50));
        pPbtnSend->setMaximumSize(QSize(50, 50));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/newPrefix/TEXT.png"), QSize(), QIcon::Normal, QIcon::Off);
        pPbtnSend->setIcon(icon3);
        pPbtnSend->setIconSize(QSize(50, 50));

        horizontalLayout->addWidget(pPbtnSend);

        pPbtnClose = new QPushButton(Chat);
        pPbtnClose->setObjectName(QString::fromUtf8("pPbtnClose"));
        pPbtnClose->setMinimumSize(QSize(50, 50));
        pPbtnClose->setMaximumSize(QSize(50, 50));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/newPrefix/iTunes.png"), QSize(), QIcon::Normal, QIcon::Off);
        pPbtnClose->setIcon(icon4);
        pPbtnClose->setIconSize(QSize(50, 50));

        horizontalLayout->addWidget(pPbtnClose);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        gridLayout->addLayout(horizontalLayout, 2, 0, 1, 1);


        retranslateUi(Chat);

        pTwgtChat->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(Chat);
    } // setupUi

    void retranslateUi(QDialog *Chat)
    {
        Chat->setWindowTitle(QApplication::translate("Chat", "Chat", 0, QApplication::UnicodeUTF8));
        pTbtnViedoChat->setText(QString());
        pTbtnFileTransfer->setText(QApplication::translate("Chat", "File transfer", 0, QApplication::UnicodeUTF8));
        pTbtnOther->setText(QApplication::translate("Chat", "Other", 0, QApplication::UnicodeUTF8));
        pPbtnSend->setText(QString());
        pPbtnClose->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Chat: public Ui_Chat {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHAT_H
