/****************************************************************************
*Copyright(c)2010     Teleca company.
*All rights reserved.��
*
*Name: chat.cpp
*Description: Implemention of Chat Dialog
*                         
*Author: Ted Zhang
*
*Version: 1.0
*
*Modified time: June 28, 2010
****************************************************************************/
#include <QtGui>
#include "chat.h"

//Constructor
Chat::Chat(QWidget *parent) : QDialog(parent)
	{
	setupUi(this);
	
//	pTwgtChat->removeTab(1);
//	m_LstSendTextEdit.append(pPteSendEdit);
//	m_LstReceiveTextEdit.append(pPteReceiveEdit);
	QObject::connect(pPbtnClose, SIGNAL(clicked()),
					 this, SLOT(close()));
	QObject::connect(pPbtnSend,SIGNAL(clicked()),
					 this, SLOT(outPut()));
	
	}
Chat::~Chat()
	{
	QObject::disconnect(pPbtnClose,SIGNAL(clicked()),
						this,SLOT(close()));
	}
void Chat::outPut()
	{
	QString strContent;
	for (int i=0;i<m_LstSendTextEdit.size();i++)
	{
	strContent = m_LstSendTextEdit.at(i)->toPlainText();
	m_LstReceiveTextEdit.at(i)->setPlainText(strContent);
	}
	
	}
void Chat::draw(QListWidgetItem *item)
	{
		QString strPageName = item->text();
		bool bAddFlag = false;
		if(!m_LstFriendName.contains(strPageName))
			{
			m_LstFriendName.append(strPageName);
			bAddFlag = true;
			}

		if(bAddFlag)
		{
			 int iNumber = m_LstFriendName.size();
			 QWidget *pWgtTempWidget = new QWidget();
			 
			 pWgtTempWidget->setObjectName(m_LstFriendName[iNumber-1]);
			 
			 QVBoxLayout *pVblVerticalLayout = new QVBoxLayout(pWgtTempWidget);
			 pVblVerticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
			 QPlainTextEdit *pPteReceiveTextEdit = new QPlainTextEdit(pWgtTempWidget);
			 m_LstReceiveTextEdit.append(pPteReceiveTextEdit);		
			 pPteReceiveTextEdit->setObjectName(QString::fromUtf8("ReceiveTextEdit"));
		     
			 QBrush brhBrush(QColor(180, 188, 255, 255));
			 brhBrush.setStyle(Qt::SolidPattern);
			 QPalette pltTemppalette;
		     QBrush brhTempbrush(QColor(246, 255, 239, 255));
		     brhTempbrush.setStyle(Qt::SolidPattern);
		     pltTemppalette.setBrush(QPalette::Active, QPalette::Base, brhTempbrush);
		     pltTemppalette.setBrush(QPalette::Inactive, QPalette::Base, brhTempbrush);
		     pltTemppalette.setBrush(QPalette::Disabled, QPalette::Base, brhBrush);
		     pPteReceiveTextEdit->setPalette(pltTemppalette);
		     pVblVerticalLayout->addWidget(pPteReceiveTextEdit);
			 
			 QFrame *pFrmline = new QFrame(pWgtTempWidget);
			 pFrmline->setObjectName(QString::fromUtf8("line"));
			 pFrmline->setFrameShape(QFrame::HLine);
			 pFrmline->setFrameShadow(QFrame::Sunken);

			 pVblVerticalLayout->addWidget(pFrmline);

			 QPlainTextEdit *pPteSendTextEdit = new QPlainTextEdit(pWgtTempWidget);
			 pPteSendTextEdit->setObjectName(QString::fromUtf8("sendTextEdit"));
			 m_LstSendTextEdit.append(pPteSendTextEdit);
			 pPteSendTextEdit->setPalette(pltTemppalette);
			 
			 pVblVerticalLayout->addWidget(pPteSendTextEdit);
//			 QIcon iconTempicon;
//			 iconTempicon.addFile(QString::fromUtf8(":/newPrefix/Contacts.png"), QSize(), QIcon::Normal, QIcon::Off);
//			 pTwgtChat->insertTab(iNumber-1,pWgtTempWidget,iconTempicon,m_LstFriendName[iNumber-1]);
			 pTwgtChat->insertTab(iNumber-1,pWgtTempWidget,m_LstFriendName[iNumber-1]);
			 pTwgtChat->setTabText(iNumber-1,m_LstFriendName[iNumber-1]);
			 pTwgtChat->setCurrentIndex(m_LstFriendName.size()-1);
			 
		}
		else
		{
			pTwgtChat->setCurrentIndex(m_LstFriendName.indexOf(strPageName));	 
		}


		showFullScreen();
	}
