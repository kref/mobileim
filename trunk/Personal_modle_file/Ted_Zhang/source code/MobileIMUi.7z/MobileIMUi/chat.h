/****************************************************************************
*Copyright(c)2010     Teleca company.
*All rights reserved.��
*
*Name: chat.h
*Description: The header file of Chat Dialog
*                         
*Author: Ted Zhang
*
*Version: 1.1
*
*Modified time: June 28, 2010
****************************************************************************/
#ifndef CHAT_H
#define CHAT_H

#include <QtGui>
#include "ui_Chat.h"
#include "MobileIMUi.h"


class Chat : public QDialog, public Ui::Chat
	{
		Q_OBJECT
public:
		Chat(QWidget *parent=0);
		~Chat();
		/********************************************************
		 * Function: When doubleclicked the friend name,and draw the chat dialog
		 * Parameters:    param1����item the member in friend name list
		 * 	              param2����Description��
		 * 		  		  param3����Description��
		 * Return value: void
		 ********************************************************/		
		void draw(QListWidgetItem *item);
public slots:
		void outPut();
public:
		QList<QString> m_LstFriendName;
		QList<QPlainTextEdit*> m_LstSendTextEdit;
		QList<QPlainTextEdit*> m_LstReceiveTextEdit;
		
	};
#endif
