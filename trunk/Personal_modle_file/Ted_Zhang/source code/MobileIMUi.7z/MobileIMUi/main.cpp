#include <QtGui/QApplication>
#include "MobileIMUi.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MobileIMUi w;
    w.showFullScreen();
//    w.showMaximized();
    return a.exec();
}
