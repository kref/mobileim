#ifndef LOGIN_H
#define LOGIN_H

#include<QDialog>
#include"ui_Login.h"

class Login : public QDialog, Ui_Dialog
{
    Q_OBJECT
public:
    Login(QWidget *pParent = 0);

    QString getUserName();
    QString getPassword();

    void setUserName();
    void setPassword();

private slots:
    void openMobileIM();

private:
    QString m_strUserName;
    QString m_strPassword;
};

#endif // LOGIN_H
