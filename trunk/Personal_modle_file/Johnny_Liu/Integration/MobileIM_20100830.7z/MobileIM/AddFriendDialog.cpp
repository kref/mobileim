#include <QtGui/QDialog>
#include <QMessageBox>
#include "AddFriendDialog.h"

AddFriendDialog::AddFriendDialog() //: QDialog(parent)
{
    setupUi(this);
    QObject::connect(pPbtnOk,SIGNAL(clicked()),this,SLOT(getInputInfo()));
    QObject::connect(pPbtnCancel,SIGNAL(clicked()),this,SLOT(close()));
}
AddFriendDialog::~AddFriendDialog()
{
    QObject::disconnect(pPbtnOk,SIGNAL(clicked()),this,SLOT(getInputInfo()));
    QObject::disconnect(pPbtnCancel,SIGNAL(clicked()),this,SLOT(close()));
}
void AddFriendDialog::getInputInfo()
{
    QString text = lineEdit->text();
    if(text == NULL)
    {
        QMessageBox warningBox;
        warningBox.setText(tr("Please input the name!"));
        warningBox.setStandardButtons(QMessageBox::Ok);

        //Modal dialog
        warningBox.exec();
    }
    else
    {
        emit getInfoFinished(text);
        this->close();
    }

}
