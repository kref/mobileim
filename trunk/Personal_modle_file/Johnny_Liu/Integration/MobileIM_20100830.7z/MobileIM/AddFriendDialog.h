#ifndef ADDFRIENDDIALOG_H
#define ADDFRIENDDIALOG_H
#include <QtGui/QDialog>
#include "ui_AddFriendDialog.h"

class AddFriendDialog : public QDialog,public Ui::AddFriendDlg
{
    Q_OBJECT
public:
    AddFriendDialog();
    ~AddFriendDialog();
signals:
    /********************************************************
    * Function: When finish input and click the ok button, 
    * get the input information, then emit the finished siganl. 
    *@item: The name of members or groups.
    ********************************************************/
    void getInfoFinished(QString txt);
private slots:
    /********************************************************
    * Function: When finish input and click the ok button,
    * get the input information.
    ********************************************************/
    void getInputInfo();
};










#endif // ADDFRIENDDIALOG_H
