#include "Login.h"
#include "MobileIMUi.h"
#include <QMessageBox>

Login::Login(QWidget *pParent):QDialog(pParent),
m_strUserName(""), m_strPassword("")
{
    setupUi(this);

    connect(pLedtUserName, SIGNAL(textChanged(const QString &text)),
            this, SLOT(enableLogin(const QString &text)));

    connect(pPbtnLogin, SIGNAL(clicked()), this, SLOT(openMobileIM()));

    connect(pPbtnUndo, SIGNAL(clicked()), this, SLOT(close()));
}

QString Login::getUserName()
{
    return m_strUserName;
}

QString Login::getPassword()
{
    return m_strPassword;
}

void Login::setUserName()
{
    m_strUserName = pLedtUserName->text();
}

void Login::setPassword()
{
    m_strPassword = pLedtPassword->text();
}

void Login::openMobileIM()
{
    if (pLedtUserName->text().isEmpty()) {
        QMessageBox::warning(NULL, "User name is empty!",
                             "Your user name is empty, please input them.");
    }

    else if (pLedtPassword->text().isEmpty()) {
        QMessageBox::warning(NULL, "Password is empty!",
                             "Your password is empty, please input them.");
    }

    else
    {
        this->close();

        MobileIMUi *pMobileIM = new MobileIMUi;
        pMobileIM->showNormal();
    }
}
