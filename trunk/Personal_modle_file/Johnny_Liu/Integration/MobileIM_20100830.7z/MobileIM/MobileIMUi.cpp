/****************************************************************************
*Copyright(c)2010     Teleca company.
*All rights reserved.��
*
*Name: MobileIM.cpp
*Description: Implemention of MobileIM main UI
*                         
*Author: Ted Zhang
*
*Version: 1.1
*
*Modified time: July 28, 2010
****************************************************************************/
#include <QAction>
#include "MobileIMUi.h"
#include "chat.h"
#include "AddFriendDialog.h"

MobileIMUi::MobileIMUi()
{
    setupUi(this);
    pLwAllContacts = new QListWidget;
    pLwiMyName = new QListWidgetItem("My Name");	
    pLwAllContacts->addItem(pLwiMyName);

    pTBoxContactsGroups->addItem((QWidget*)pLwAllContacts,tr("All Contacts"));

    m_LstMemberList.append(pLwiMyName);
	
    pChatwindow = new Chat;


    pAddMembers = new QAction("Add Members",this);
    pAddGroups = new QAction("Add Groups",this);
    pExit = new QAction("Exit",this);
    pCancle = new QAction("Cancle",this);

    QObject::connect(pPbtnMenu, SIGNAL(clicked()),
                     this, SLOT(drawMenu()));
    QObject::connect(pLwAllContacts,SIGNAL(itemDoubleClicked(QListWidgetItem*)),
                     this,SLOT(goToChat(QListWidgetItem*)));
    QObject::connect(pAddMembers,SIGNAL(triggered()),
                     this,SLOT(openAddFriendDialog()));
    QObject::connect(pAddGroups,SIGNAL(triggered()),
                     this,SLOT(openAddGroupDialog()));
    QObject::connect(pCancle,SIGNAL(triggered()),
                     this,SLOT(cancle()));	
    QObject::connect(pExit,SIGNAL(triggered()),
                     this,SLOT(close()));

}

MobileIMUi::~MobileIMUi()
{  
    delete pLwiMyName;	
    pLwiMyName = NULL;
    delete pAddMembers;
    pAddMembers = NULL;
    delete pAddGroups;
    pAddGroups = NULL;
    delete pExit;
    pExit = NULL;
    delete pCancle;
    pCancle = NULL;
    delete pChatwindow;
    pChatwindow = NULL;
	
    
    QObject::disconnect(pPbtnMenu, SIGNAL(clicked()),
                        this, SLOT(addMember()));
    QObject::disconnect(pLwAllContacts,SIGNAL(itemDoubleClicked(QListWidgetItem*)),
                        this,SLOT(goToChat(QListWidgetItem*)));
    QObject::disconnect(pAddMembers,SIGNAL(triggered()),
                        this,SLOT(openAddFriendDialog()));
    QObject::disconnect(pAddGroups,SIGNAL(triggered()),
                        this,SLOT(openAddGroupDialog()));
    QObject::disconnect(pExit,SIGNAL(triggered()),
                        this,SLOT(close()));
    QObject::disconnect(pCancle,SIGNAL(triggered()),
                        this,SLOT(cancle()));

}
void MobileIMUi::openAddFriendDialog()
{
    AddFriendDialog *pAddFriendDlg = new AddFriendDialog;
    //pAddFriendDlg->showFullScreen();
    pAddFriendDlg->showNormal();
    QObject::connect(pAddFriendDlg,SIGNAL(getInfoFinished(QString)),
                        this,SLOT(addMembers(QString)));

}
void MobileIMUi::openAddGroupDialog()
{
    AddFriendDialog *pAddFriendDlg = new AddFriendDialog;
    pAddFriendDlg->label->setText("Please input group name:");
    //pAddFriendDlg->showFullScreen();
    pAddFriendDlg->showNormal();
    QObject::connect(pAddFriendDlg,SIGNAL(getInfoFinished(QString)),
                        this,SLOT(addGroups(QString)));
}
void MobileIMUi::addMembers(QString name)
{
    QListWidgetItem *pLsiNewitem1 = new QListWidgetItem(name);
    m_LstMemberList.append(pLsiNewitem1);
	
    for(int i = 1;i < m_LstMemberList.size();i++)
    {
        pLwAllContacts->addItem(m_LstMemberList.at(i));
    }


}

void MobileIMUi::addGroups(QString name)
{
    QListWidget *pLwNewGroup = new QListWidget;
    pTBoxContactsGroups->addItem((QWidget*)pLwNewGroup,name);
}

void MobileIMUi::goToChat(QListWidgetItem *item)
{
    pChatwindow->draw(item);
}
	
void MobileIMUi::drawMenu()
{	    
    this->setEnabled(false);

    QMenu *popMenu = new QMenu(this);
    popMenu->addAction(pAddMembers);
    popMenu->addAction(pAddGroups);
    popMenu->addAction(pCancle);
    popMenu->addAction(pExit);
   
    popMenu->exec(QCursor::pos()); //popMenu displayed at the current mouse position

    this->setEnabled(true);
}



