/****************************************************************************
** Meta object code from reading C++ file 'AddFriendDialog.h'
**
** Created: Mon Aug 30 17:19:47 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../AddFriendDialog.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'AddFriendDialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_AddFriendDialog[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      21,   17,   16,   16, 0x05,

 // slots: signature, parameters, type, tag, flags
      46,   16,   16,   16, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_AddFriendDialog[] = {
    "AddFriendDialog\0\0txt\0getInfoFinished(QString)\0"
    "getInputInfo()\0"
};

const QMetaObject AddFriendDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_AddFriendDialog,
      qt_meta_data_AddFriendDialog, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &AddFriendDialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *AddFriendDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *AddFriendDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_AddFriendDialog))
        return static_cast<void*>(const_cast< AddFriendDialog*>(this));
    if (!strcmp(_clname, "Ui::AddFriendDlg"))
        return static_cast< Ui::AddFriendDlg*>(const_cast< AddFriendDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int AddFriendDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: getInfoFinished((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: getInputInfo(); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void AddFriendDialog::getInfoFinished(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
