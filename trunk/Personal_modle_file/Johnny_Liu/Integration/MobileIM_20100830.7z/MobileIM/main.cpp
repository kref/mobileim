#include <QtGui/QApplication>
//#include "MobileIMUi.h"
#include "Login.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
	
    //MobileIMUi w;
    //Johnny changed for windows style
    //In phone style, we should use this.
   // w.showFullScreen();
   // w.showNormal();
    Login loginDialog;
    loginDialog.showNormal();
    return a.exec();
}
