/********************************************************************************
** Form generated from reading UI file 'ImSocketServer2.ui'
**
** Created: Thu Jun 10 14:21:11 2010
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_IMSOCKETSERVER2_H
#define UI_IMSOCKETSERVER2_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ImSocketServer2
{
public:

    void setupUi(QWidget *ImSocketServer2)
    {
        if (ImSocketServer2->objectName().isEmpty())
            ImSocketServer2->setObjectName(QString::fromUtf8("ImSocketServer2"));
        ImSocketServer2->resize(400, 300);

        retranslateUi(ImSocketServer2);

        QMetaObject::connectSlotsByName(ImSocketServer2);
    } // setupUi

    void retranslateUi(QWidget *ImSocketServer2)
    {
        ImSocketServer2->setWindowTitle(QApplication::translate("ImSocketServer2", "ImSocketServer2", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ImSocketServer2: public Ui_ImSocketServer2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_IMSOCKETSERVER2_H
