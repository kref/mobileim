#include <QtGui>
#include <QApplication>
#include <iostream>

#include "Server.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    
    std::cerr << "Try to bind to port 6178" << std::endl;
    Server server;
    if (!server.listen(QHostAddress::Any, 6178)) {
        std::cerr << "Failed to bind to port" << std::endl;
        return 1;
    }
    
    QPushButton quitButton(QObject::tr("&Quit"));
    quitButton.setWindowTitle(QObject::tr("IM Server"));
    QObject::connect(&quitButton, SIGNAL(clicked()),
                     &a, SLOT(quit()));
    quitButton.show();

    return a.exec();
}
