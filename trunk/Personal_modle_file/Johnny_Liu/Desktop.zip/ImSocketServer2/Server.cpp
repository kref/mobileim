/*
 * Server.cpp
 *
 *  Created on: Jun 8, 2010
 *      Author: cninteli
 */

#include "clientsocket.h"
#include "Server.h"

Server::Server(QObject *parent):
QTcpServer(parent)
	{
	// TODO Auto-generated constructor stub
	}

Server::~Server()
	{
	// TODO Auto-generated destructor stub
	}

void Server::incomingConnection(int socketId)
	{
    ClientSocket *socket = new ClientSocket(this);
    socket->setSocketDescriptor(socketId);    
	}
