/*
 * Server.h
 *
 *  Created on: Jun 8, 2010
 *      Author: cninteli
 */

#ifndef SERVER_H_
#define SERVER_H_
#include <QTcpServer>
class Server: public QTcpServer
	{
	Q_OBJECT
public:
	Server(QObject *parent = 0);
	virtual ~Server();
private:
    void incomingConnection(int socketId);
	};

#endif /* SERVER_H_ */
