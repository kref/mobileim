#include <QtNetwork/QHostAddress>
#include <QtNetwork/QAbstractSocket>

#include "IMSocketClient.h"

IMSocketClient::IMSocketClient(QWidget *parent)
    : QDialog(parent)
{
	ui = new Ui_IMSocketClient;
	ui->setupUi(this);
	ui->connectButton->setEnabled(true);
	ui->sendButton->setEnabled(false);
	
    connect(ui->connectButton, SIGNAL(clicked()), this, SLOT(connectToServer()));
    
    connect(&tcpSocket, SIGNAL(connected()), this, SLOT(updateStatus()));
    connect(&tcpSocket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(error()));
    connect(&tcpSocket, SIGNAL(disconnected()), this, SLOT(connectionClosedByServer()));
    connect(&tcpSocket, SIGNAL(readyRead()), this, SLOT(receiveDataFromServer()));
    
    connect(ui->sendButton, SIGNAL(clicked()), this, SLOT(sendRequest()));
    connect(ui->exitButton, SIGNAL(clicked()), this, SLOT(reject()));
}

IMSocketClient::~IMSocketClient()
{
	tcpSocket.close();
}

void IMSocketClient::connectToServer()
	{
	nextBlockSize = 0;
	if(tcpSocket.isValid())
		tcpSocket.close();
	tcpSocket.connectToHost(QHostAddress::LocalHost, 6178);	
	ui->statusLabel->setText(tr("Connecting"));	    
	ui->connectButton->setEnabled(false);
	}

void IMSocketClient::updateStatus()
	{
	ui->statusLabel->setText(tr("Connected"));	 
	ui->connectButton->setEnabled(false);
	ui->sendButton->setEnabled(true);
	}

void IMSocketClient::error()
	{
	ui->connectButton->setEnabled(true);
	ui->statusLabel->setText(tcpSocket.errorString());
	closeConnection();
	}

void IMSocketClient::sendRequest()
	{
	connectToServer(); //Why cannot get the answer from server since secondary send request?
	ui->statusLabel->setText(tr("Sending message"));
	
	QString message = ui->sendMessageLE->text();
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_4_7);
    out << quint16(0) << quint8('S') << message;

    out.device()->seek(0);
    out << quint16(block.size() - sizeof(quint16));
    tcpSocket.write(block);
	
	upatedChatRecord(message); //To update chat record after sending message
	ui->sendMessageLE->clear();
	}

//To update chat record after sending message and recieving message from server
void IMSocketClient::upatedChatRecord(QString chatMessage)
	{
	ui->statusLabel->setText(tr("Connected"));		
	ui->chatRecordBrowser->append(chatMessage);		
	}

void IMSocketClient::receiveDataFromServer()
	{
	ui->statusLabel->setText(tr("Receiving message"));
	
	QDataStream in(&tcpSocket);
	    in.setVersion(QDataStream::Qt_4_7);

	    forever {	        
	        if (nextBlockSize == 0) 
	        	{
	            if (tcpSocket.bytesAvailable() < sizeof(quint16))
	                break;
	            in >> nextBlockSize;
	            }

	        if (nextBlockSize == 0xFFFF) {
	            //closeConnection();	//We need to keep the connection because this is a chat app            
	            break;
	        }
	        if (tcpSocket.bytesAvailable() < nextBlockSize)
	            break;

	        QString chatMessage;
	        in >> chatMessage;	        
	       
	        upatedChatRecord(chatMessage);	 
	        
	        nextBlockSize = 0;
	    }
	}

void IMSocketClient::connectionClosedByServer()
	{
    if (nextBlockSize != 0xFFFF)
    	ui->statusLabel->setText(tr("Error: Connection closed by server"));
	closeConnection();
	}

void IMSocketClient::closeConnection()
	{
	tcpSocket.close();
	ui->connectButton->setEnabled(true);
	ui->sendButton->setEnabled(false);
	}
