/****************************************************************************
*Copyright(c)2010     Teleca company.
*All rights reserved.��
*
*Name: chat.h
*Description: The header file of Chat Dialog
*                         
*Author: Ted Zhang
*
*Version: 1.1
*
*Modified time: July 28, 2010
****************************************************************************/
#ifndef CHAT_H
#define CHAT_H

#include <QtGui>
#include "ui_Chat.h"
#include "MobileIMUi.h"
#include "UdpCS.h"


class Chat : public QDialog, public Ui::Chat
{
    Q_OBJECT
		
public:
    Chat(QWidget *parent=0);
    ~Chat();
    
    /********************************************************
    * Function: When double clicked the friend name,and draw the chat dialog
    *
    * @item: The member in friend name list
    ********************************************************/		
    void draw(QListWidgetItem *item);
		
public slots:
//    void outPut();
    void sendChatDatas();
    void receivedChatDatas();
    void closeTabPage(int);
public:
    QList<QString> m_lstFriendName;
    QList<QPlainTextEdit*> m_lstSendTedt;
    QList<QPlainTextEdit*> m_lstRecvTedt;

    UdpCS *pUdpCS;

};

#endif
