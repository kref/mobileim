/****************************************************************************
*Copyright(c)2010     Teleca company.
*All rights reserved.
*
*Name: chat.cpp
*Description: Implemention of Chat Dialog
*                         
*Author: Ted Zhang
*
*Version: 1.1
*
*Modified time: August 11, 2010
****************************************************************************/
#include <QtGui>
#include "chat.h"


//Constructor
Chat::Chat(QWidget *parent) : QDialog(parent)
{
    setupUi(this);

//	pTwgtChat->removeTab(1);
//	m_LstSendTextEdit.append(pPteSendEdit);
//	m_LstReceiveTextEdit.append(pPteReceiveEdit);
    connect(pPbtnClose, SIGNAL(clicked()),
                     this, SLOT(close()));
//    QObject::connect(pPbtnSend,SIGNAL(clicked()),
//                     this, SLOT(outPut()));
    connect (pPbtnSend, SIGNAL(clicked()), this, SLOT(sendChatDatas()));
    connect(pTwgtChat,SIGNAL(tabCloseRequested(int)),this,SLOT(closeTabPage(int)));
    pUdpCS = new UdpCS(this);
}

Chat::~Chat()
{
    QObject::disconnect(pPbtnClose,SIGNAL(clicked()),
                        this,SLOT(close()));

    delete pUdpCS;
    pUdpCS = NULL;
}

void Chat::sendChatDatas()
{
    QString strSendContents;

    for (int i = 0; i < m_lstSendTedt.size(); ++i) {
        strSendContents = m_lstSendTedt.at(i)->toPlainText();
    }

    pUdpCS->sendDataToServer(strSendContents,
                             QHostAddress::LocalHost, 5050);
}

void Chat::receivedChatDatas()
{
    QString strRecvFromStream = pUdpCS->receivedData();

    QString strRecvLocal;
    QString strRecvContents;

    for (int i = 0; i < m_lstRecvTedt.size(); ++i) {
        strRecvLocal = m_lstRecvTedt.at(i)->toPlainText();
        strRecvContents = strRecvLocal + "\n" +
                                      strRecvFromStream;
        m_lstRecvTedt.at(i)->setPlainText(strRecvContents);
    }
}

/*
void Chat::outPut()
{
    QString strContent;
    for (int i=0; i<m_LstSendTextEdit.size(); i++)
    {
        strContent = m_LstSendTextEdit.at(i)->toPlainText();
        m_LstReceiveTextEdit.at(i)->setPlainText(strContent);
    }	
}
*/

void Chat::draw(QListWidgetItem *item)
{
    QString strPageName = item->text();
    bool bAddFlag = false;
	
    if(!m_lstFriendName.contains(strPageName))
    {
        m_lstFriendName.append(strPageName);
        bAddFlag = true;
    }

    if( bAddFlag )
    {
        int iNumber = m_lstFriendName.size();
        QWidget *pWgtTempWidget = new QWidget();
			 
        pWgtTempWidget->setObjectName(m_lstFriendName[iNumber-1]);
			 
        QVBoxLayout *pVblVerticalLayout = new QVBoxLayout(pWgtTempWidget);
        pVblVerticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        QPlainTextEdit *pPteReceiveTextEdit = new QPlainTextEdit(pWgtTempWidget);
        m_lstRecvTedt.append(pPteReceiveTextEdit);
        pPteReceiveTextEdit->setObjectName(QString::fromUtf8("ReceiveTextEdit"));
		     
        QBrush brhBrush(QColor(180, 188, 255, 255));
        brhBrush.setStyle(Qt::SolidPattern);
        QPalette pltTemppalette;
        QBrush brhTempbrush(QColor(246, 255, 239, 255));
        brhTempbrush.setStyle(Qt::SolidPattern);
        pltTemppalette.setBrush(QPalette::Active, QPalette::Base, brhTempbrush);
        pltTemppalette.setBrush(QPalette::Inactive, QPalette::Base, brhTempbrush);
        pltTemppalette.setBrush(QPalette::Disabled, QPalette::Base, brhBrush);
        pPteReceiveTextEdit->setPalette(pltTemppalette);
        pVblVerticalLayout->addWidget(pPteReceiveTextEdit);
			 
        QFrame *pFrmline = new QFrame(pWgtTempWidget);
        pFrmline->setObjectName(QString::fromUtf8("line"));
        pFrmline->setFrameShape(QFrame::HLine);
        pFrmline->setFrameShadow(QFrame::Sunken);

        pVblVerticalLayout->addWidget(pFrmline);

        QPlainTextEdit *pPteSendTextEdit = new QPlainTextEdit(pWgtTempWidget);
        pPteSendTextEdit->setObjectName(QString::fromUtf8("sendTextEdit"));
        m_lstSendTedt.append(pPteSendTextEdit);
        pPteSendTextEdit->setPalette(pltTemppalette);

        pVblVerticalLayout->addWidget(pPteSendTextEdit);
//			 QIcon iconTempicon;
//			 iconTempicon.addFile(QString::fromUtf8(":/newPrefix/Contacts.png"), QSize(), QIcon::Normal, QIcon::Off);
//			 pTwgtChat->insertTab(iNumber-1,pWgtTempWidget,iconTempicon,m_lstFriendName[iNumber-1]);
        pTwgtChat->insertTab(iNumber-1,pWgtTempWidget,m_lstFriendName[iNumber-1]);
        pTwgtChat->setTabText(iNumber-1,m_lstFriendName[iNumber-1]);
        pTwgtChat->setCurrentIndex(m_lstFriendName.size()-1);

        pTwgtChat->setTabsClosable(true);

    }

    else
    {
        pTwgtChat->setCurrentIndex(m_lstFriendName.indexOf(strPageName));
    }

        //Johnny changed for windows style
        //In phone style, we should use this.
        //showFullScreen();
        showNormal();       
}
void Chat::closeTabPage(int page)
{
    if( 1 == m_lstFriendName.size())
    {
        m_lstFriendName.removeAt(page);
        pTwgtChat->removeTab(page);
        this->close();
    }
    else
    {
        m_lstFriendName.removeAt(page);
        pTwgtChat->removeTab(page);
    }

}
