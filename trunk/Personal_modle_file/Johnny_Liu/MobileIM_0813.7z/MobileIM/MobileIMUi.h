/****************************************************************************
*Copyright(c)2010     Teleca company.
*All rights reserved.
*
*Name: MobileIM.h
*Description: The header file of MobileIM main UI
*
*Author: Ted Zhang
*
*Version: 1.1
*
*Modified time: July 28, 2010
****************************************************************************/

#ifndef MOBILEIMUIMAIN_H
#define MOBILEIMUIMAIN_H

#include <QtGui/QWidget>
#include "ui_MobileIMUi.h"
#include "chat.h"

class Chat;

class MobileIMUi : public QMainWindow, public Ui::MobileIM
{
    Q_OBJECT

public:
    //Constructor
    MobileIMUi();
	
    //Destructor
    ~MobileIMUi();
	
public slots:
    /********************************************************
     * Function: Add members in friend list.
    ********************************************************/
    void addMembers();
		
    /********************************************************
    * Function: Spread and shrink the friend list
    ********************************************************/
    void addGroups();
		
    /********************************************************
    * Function: When double click the friend name, call the chat dialog
    *@item: The members in friend name list.
    ********************************************************/
    void goToChat(QListWidgetItem *item);
    
    /********************************************************
    * Function: When clicked the menu button,and draw the popup menu
    ********************************************************/
    void drawMenu();

public:
    QVBoxLayout *layout1;
    QVBoxLayout *layout2;
    QListWidget *pLwAllContacts;
		
    //Record myself name
    QListWidgetItem *pLwiMyName;
		
    //Record the all members of friends 
    QList<QListWidgetItem*> m_LstMemberList;
		
    QAction *pAddMembers;
    QAction *pAddGroups;
    QAction *pExit;
    QAction *pCancle;
    
    //Chat Dialog
    Chat *pChatwindow;


private:
    //Record the times of clicked 'All Contacts' button
    int m_iClickedTime;
};

#endif // MOBILEIMUIMAIN_H
