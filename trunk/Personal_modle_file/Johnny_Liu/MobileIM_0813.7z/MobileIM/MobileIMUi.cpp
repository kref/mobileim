/****************************************************************************
*Copyright(c)2010     Teleca company.
*All rights reserved.��
*
*Name: MobileIM.cpp
*Description: Implemention of MobileIM main UI
*                         
*Author: Ted Zhang
*
*Version: 1.1
*
*Modified time: July 28, 2010
****************************************************************************/
#include <QMessageBox>
#include <QAction>
#include "MobileIMUi.h"
#include "chat.h"

MobileIMUi::MobileIMUi()
{
    setupUi(this);
    pLwAllContacts = new QListWidget;
    pLwiMyName = new QListWidgetItem("My Name");	
    pLwAllContacts->addItem(pLwiMyName);

    pTBoxContactsGroups->addItem((QWidget*)pLwAllContacts,tr("All Contacts"));

    m_LstMemberList.append(pLwiMyName);
	
    pChatwindow = new Chat;
	
    pAddMembers = new QAction("Add Members",this);
    pAddGroups = new QAction("Add Groups",this);
    pExit = new QAction("Exit",this);
    pCancle = new QAction("Cancle",this);

    QObject::connect(pPbtnMenu, SIGNAL(clicked()),
                     this, SLOT(drawMenu()));
    QObject::connect(pLwAllContacts,SIGNAL(itemDoubleClicked(QListWidgetItem*)),
                     this,SLOT(goToChat(QListWidgetItem*)));
    QObject::connect(pAddMembers,SIGNAL(triggered()),
                     this,SLOT(addMembers()));
    QObject::connect(pAddGroups,SIGNAL(triggered()),
                     this,SLOT(addGroups()));
    QObject::connect(pCancle,SIGNAL(triggered()),
                     this,SLOT(cancle()));	
    QObject::connect(pExit,SIGNAL(triggered()),
                     this,SLOT(close()));
    
}

MobileIMUi::~MobileIMUi()
{  
    delete pLwiMyName;

    QObject::disconnect(pPbtnMenu, SIGNAL(clicked()),
                        this, SLOT(addMember()));
    QObject::disconnect(pLwAllContacts,SIGNAL(itemDoubleClicked(QListWidgetItem*)),
                        this,SLOT(goToChat(QListWidgetItem*)));
    QObject::disconnect(pAddMembers,SIGNAL(triggered()),
                        this,SLOT(addMembers()));
    QObject::disconnect(pAddGroups,SIGNAL(triggered()),
                        this,SLOT(addGroups()));
    QObject::disconnect(pExit,SIGNAL(triggered()),
                        this,SLOT(close()));
    QObject::disconnect(pCancle,SIGNAL(triggered()),
                        this,SLOT(cancle()));
}

void MobileIMUi::addMembers()
{
    QListWidgetItem *pLsiNewitem1 = new QListWidgetItem("Myfriend1");
    QListWidgetItem *pLsiNewitem2 = new QListWidgetItem("Myfriend2");
	
    m_LstMemberList.append(pLsiNewitem1);
    m_LstMemberList.append(pLsiNewitem2);
	
    for(int i = 1;i < m_LstMemberList.size();i++)
    {
        pLwAllContacts->addItem(m_LstMemberList.at(i));
    }		
}

void MobileIMUi::addGroups()
{
    QListWidget *pLwNewGroup = new QListWidget;
    pTBoxContactsGroups->addItem((QWidget*)pLwNewGroup,tr("My Friends"));
}

void MobileIMUi::goToChat(QListWidgetItem *item)
{
    pChatwindow->draw(item);
}
	
void MobileIMUi::drawMenu()
{	    
    this->setEnabled(false);

    QMenu *popMenu = new QMenu(this);
    popMenu->addAction(pAddMembers);
    popMenu->addAction(pAddGroups);
    popMenu->addAction(pCancle);
    popMenu->addAction(pExit);
   
    popMenu->exec(QCursor::pos()); //popMenu displayed at the current mouse position

    this->setEnabled(true);
}



