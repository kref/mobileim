#include "weatherinfo.h"
/*
WeatherInfo::WeatherInfo()
{
}
*/
