/****************************************************************
����Copyright(c)2010     Teleca company.
����All rights reserved.
��
�����ļ����ƣ�mainwindow.cpp
������Ҫ������ �ͻ���UI
��
������ǰ�汾��0.1
��������/�޸��ߣ�Zor Li
����������ڣ�
�����޶�˵����
��
����ȡ���汾��1.0
�����޸��ˣ�
����������ڣ�
�����޶�˵����
*****************************************************************/
#include "mainwindow.h"
#include "ui_mainwindow.h"

/**************************************************************
* �������ƣ�MainWindow
* ����������structure
* �����б���parent -------- parent
* ���ؽ����NULL
***************************************************************/
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    m_socket = NULL;
    m_clientID = "1234567899";
    m_password = "1111111";
    m_hostAddress = QHostAddress::LocalHost;
    m_hostPort = 9000;
    m_defaultIcon = QIcon(":/images/wall.png");
    this->setWindowIcon(QIcon(":/images/eve.png"));

    ui->setupUi(this);
    connect(ui->closeButton,SIGNAL(clicked()),this,SLOT(close()));
    connect(ui->connectButton,SIGNAL(clicked()),this,SLOT(slt_connectToServer()));
    connect(ui->sendButton,SIGNAL(clicked()),this,SLOT(slt_sendMsg()));

    ui->userListWidget->setSelectionMode(QAbstractItemView::MultiSelection);
    ui->userListWidget->setViewMode(QListView::IconMode);
}

/**************************************************************
* �������ƣ�~MainWindow
* ����������destory
* �����б���NULL
* ���ؽ����NULL
***************************************************************/
MainWindow::~MainWindow()
{
    delete ui;
    if(m_socket != NULL)
        delete m_socket;
}

/**************************************************************
* �������ƣ�changeEvent
* ����������
* �����б���e ------- event
* ���ؽ����void
***************************************************************/
void MainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void MainWindow::closeEvent(QCloseEvent *e)
{
    if(m_socket != NULL)
    {
        m_socket->close();
    }
    e->accept();
}

/**************************************************************
* �������ƣ�slt_connectToServer
* ����������connect to server
* �����б���NULL
* ���ؽ����void
***************************************************************/
void MainWindow::slt_connectToServer()
{
    if(!m_socket)
    {
        m_socket = new QTcpSocket();
        m_socket->connectToHost(m_hostAddress,m_hostPort);
        connect(m_socket,SIGNAL(connected()),this,SLOT(slt_connectedServer()));
        connect(m_socket,SIGNAL(readyRead()),this,SLOT(slt_recvMsg()));
        connect(m_socket,SIGNAL(stateChanged(QAbstractSocket::SocketState)),this,SLOT(slt_stateInfo(QAbstractSocket::SocketState)));
    }
}

/**************************************************************
* �������ƣ�slt_connectedServer
* ����������connect is succeed, and then login
* �����б���NULL
* ���ؽ����void
***************************************************************/
void MainWindow::slt_connectedServer()
{
    ui->historyBrowser->append("Welcome! You have logged in MoblieIM.");

    Message login;
    login.m_clientID = ui->userLineEdit->text();//this->m_clientID;
    login.m_contentType = em_ChangeState;
    login.m_msgType = em_Request;

    ClientChangeState loginReq;
    loginReq.m_password = m_password;
    loginReq.m_userState = em_UserLogin;
    login.m_msgContent = (void *)(&loginReq);

    QByteArray req;
    QDataStream out (&req, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_4_6);
    out << quint16(0) << login;
    out.device()->seek(0);
    out << quint16(req.size() - sizeof(quint16));

    this->m_socket->write(req);
}

/**************************************************************
* �������ƣ�slt_sendMsg
* ����������send text message
* �����б���NULL
* ���ؽ����void
***************************************************************/
void MainWindow::slt_sendMsg()
{
    if(ui->messageEdit->toPlainText().length() != 0)
    {
        QList<QString> friends;
        for(int i = 0; i < ui->userListWidget->count(); ++i)
        {
            if(ui->userListWidget->item(i)->isSelected())
            {
                friends.append(ui->userListWidget->item(i)->text());
            }
        }

        MessageOfText msgText;
        msgText.m_friendsNum = friends.count();
        if(msgText.m_friendsNum <= 0)
            return;
        else if(msgText.m_friendsNum == 1)
            msgText.m_chatType = em_PersonalChat;
        else if(msgText.m_friendsNum > 1)
            msgText.m_chatType = em_GroupChat;

        msgText.m_friends = friends;
        msgText.m_content = ui->messageEdit->toPlainText();

        Message message;
        message.m_clientID = this->m_clientID;
        message.m_msgType = em_SendMsg;
        message.m_contentType = em_TextMessage;
        message.m_msgContent = (void *)&msgText;

        QByteArray req;
        QDataStream out (&req, QIODevice::WriteOnly);
        out.setVersion(QDataStream::Qt_4_6);
        out << quint16(0) << message;
        out.device()->seek(0);
        out << quint16(req.size() - sizeof(quint16));

        this->m_socket->write(req);

        QString info = "My: " + msgText.m_content;
        ui->historyBrowser->append(info);
        ui->messageEdit->clear();
    }
}

/**************************************************************
* �������ƣ�slt_recvMsg
* ����������recviced message
* �����б���NULL
* ���ؽ����void
***************************************************************/
void MainWindow::slt_recvMsg()
{
    quint16 msgSize = 0;
    QDataStream in(this->m_socket);
    in.setVersion(QDataStream::Qt_4_6);
    in >> msgSize;
    if(m_socket->bytesAvailable() < msgSize)
    {
        return;
    }

    Message message;
    in >> message;
    this->handleMsg(message);
}

/**************************************************************
* �������ƣ�handleMsg
* ����������handle message
* �����б���message -------- message
* ���ؽ����void
***************************************************************/
void MainWindow::handleMsg(Message message)
{
    switch(message.m_msgType)
    {
    case em_Response:
        switch(message.m_contentType)
        {
        case em_ChangeState:
            {
                MessageOfLoginResp *loginResp = (MessageOfLoginResp *)message.m_msgContent;
                if(loginResp->m_friendsNum == loginResp->m_friendsInfo.count())
                    this->m_friends.append(loginResp->m_friendsInfo);
                this->addFriends(this->m_friends);
            }
            break;
        default:
            break;
        }
        break;
    case em_Indicator:
        switch(message.m_contentType)
        {
        case em_ChangeState:
            {
                ClientChangeState *changeState = (ClientChangeState*)message.m_msgContent;
                switch(changeState->m_userState)
                {
                case em_UserLogin:
                    {
                        QList<UserInfo*> friends;
                        UserInfo *fri = new UserInfo();
                        fri->m_userID = message.m_clientID;
                        fri->m_userState = changeState->m_userState;
                        friends.append(fri);
                        this->addFriends(friends);
                    }
                    break;
                case em_UserHiding:
                    break;
                case em_UserOut:
                    break;
                case em_UserLogout:
                    {
                        for(int i = 0; i < ui->userListWidget->count(); ++i)
                        {
                            if(ui->userListWidget->item(i)->text().compare(message.m_clientID) == 0)
                                //ui->userListWidget->item(i)->setForeground(QBrush(Qt::gray));
                                ui->userListWidget->item(i)->setHidden(true);
                        }
                    }
                    break;
                }
            }
            break;
        default:
            break;
        }
        break;
    case em_Any:
        switch(message.m_contentType)
        {
        case em_TextMessage:
            {
                MessageOfTransfer *tran = (MessageOfTransfer*)message.m_msgContent;
                QString info = message.m_clientID + ": " + tran->m_content;
                ui->historyBrowser->append(info);
            }
            break;
        case em_VoiceMessage:
            break;
        case em_VideoMessage:
            break;
        default:
            break;
        }
        break;
    default:
        break;
    }
}

/**************************************************************
* �������ƣ�addFriends
* ����������add friends list
* �����б���friends -------- friends
* ���ؽ����void
***************************************************************/
void MainWindow::addFriends(QList<UserInfo *>friends)
{
    for(int i = 0; i < friends.count(); ++i)
    {
        QListWidgetItem *item = new QListWidgetItem(friends[i]->m_userID);
        item->setIcon(m_defaultIcon);
        ui->userListWidget->addItem(item);
        //if(friends[i]->m_userState == em_UserLogin)
        //    item->setForeground(QBrush(Qt::green));
    }
}

/**************************************************************
* �������ƣ�stateInfo
* ����������change status bar
* �����б���state -------- state
* ���ؽ����void
***************************************************************/
void MainWindow::slt_stateInfo(QAbstractSocket::SocketState state)
{
    switch(state)
    {
    case QAbstractSocket::UnconnectedState:
        ui->infolabel->setText("No connect");
        break;
    case QAbstractSocket::ConnectedState:
        ui->infolabel->setText("Connected");
        break;
    case QAbstractSocket::ClosingState:
        ui->infolabel->setText("Disconnect");
        break;
    default:
        break;
    }
}
