/****************************************************************
����Copyright(c)2010     Teleca company.
����All rights reserved.
��
�����ļ����ƣ�commonLib.h
������Ҫ������ ͨ���ඨ��
��
������ǰ�汾��0.1
��������/�޸��ߣ�Zor Li
����������ڣ�
�����޶�˵����
��
����ȡ���汾��1.0
�����޸��ˣ�
����������ڣ�
�����޶�˵����
*****************************************************************/
#ifndef COMMONLIB_H
#define COMMONLIB_H

#include <QtGlobal>
#include <QDataStream>
#include <QTcpSocket>

enum UserState { em_UserLogin, em_UserHiding, em_UserOut, em_UserLogout };

enum MessageType { em_Request, em_Response, em_Indicator, em_SendMsg, em_Any };
enum ContentType { em_ChangeState, em_TextMessage, em_VoiceMessage, em_VideoMessage, em_NULL };

enum ChatType { em_GroupChat, em_PersonalChat };

struct UserInfo {
    QString m_userID;
    UserState m_userState;
    /* expand */
};

class Message {
public:
    MessageType m_msgType;
    ContentType m_contentType;
    QString m_clientID;
    /* expand */
    void *m_msgContent;

public:
    Message();
    friend QDataStream & operator << (QDataStream &dataStream, Message &msg);
    friend QDataStream & operator >> (QDataStream &dataStream, Message &msg);
};

class MessageOfTransfer {
public:
    QString m_content;
    /* expand */

public:
    MessageOfTransfer();
    friend QDataStream & operator << (QDataStream &dataStream, MessageOfTransfer &tran);
    friend QDataStream & operator >> (QDataStream &dataStream, MessageOfTransfer &tran);
};

class ClientChangeState {
public:
    UserState m_userState;
    QString m_password;

public:
    friend QDataStream & operator << (QDataStream &dataStream, ClientChangeState &changeState);
    friend QDataStream & operator >> (QDataStream &dataStream, ClientChangeState &changeState);
};

class MessageOfLoginResp {
public:
    qint16 m_friendsNum;
    QList<UserInfo *> m_friendsInfo;
    /* expand */

public:
    MessageOfLoginResp();
    ~MessageOfLoginResp();
    friend QDataStream & operator << (QDataStream &dataStream, MessageOfLoginResp &loginResp);
    friend QDataStream & operator >> (QDataStream &dataStream, MessageOfLoginResp &loginResp);
};

class MessageOfText {
public:
    ChatType m_chatType;
    qint16 m_friendsNum;
    QList<QString> m_friends;
    QString m_content;

public:
    friend QDataStream & operator << (QDataStream &dataStream, MessageOfText &textMsg);
    friend QDataStream & operator >> (QDataStream &dataStream, MessageOfText &textMsg);
};

#endif // COMMONLIB_H
