/****************************************************************
����Copyright(c)2010     Teleca company.
����All rights reserved.
��
�����ļ����ƣ�commonLib.cpp
������Ҫ������ ͨ���ඨ��
��
������ǰ�汾��0.1
��������/�޸��ߣ�Zor Li
����������ڣ�
�����޶�˵����
��
����ȡ���汾��1.0
�����޸��ˣ�
����������ڣ�
�����޶�˵����
*****************************************************************/
#include "commonLib.h"

Message::Message()
{

}


/**************************************************************
* �������ƣ�Message operator << and >>
* ����������ע�⣺&��*���ܻ���
***************************************************************/
QDataStream & operator << (QDataStream &dataStream, Message &msg)
{
    dataStream << (qint16)msg.m_msgType <<(qint16)msg.m_contentType << msg.m_clientID;

    switch(msg.m_msgType)
    {
    case em_Request:
        switch(msg.m_contentType)
        {
        case em_ChangeState:
            {
                ClientChangeState *changeState = (ClientChangeState *)msg.m_msgContent;
                dataStream << *changeState;
            }
            break;
        default:
            break;
        }
        break;
    case em_Response:
        switch(msg.m_contentType)
        {
        case em_ChangeState:
            {
                MessageOfLoginResp *loginResp = (MessageOfLoginResp *)msg.m_msgContent;
                dataStream << *loginResp;
            }
            break;
        default:
            break;
        }
        break;
    case em_Indicator:
        switch(msg.m_contentType)
        {
        case em_ChangeState:
            {
                ClientChangeState *changeState = (ClientChangeState *)msg.m_msgContent;
                dataStream << *changeState;
            }
            break;
        default:
            break;
        }
        break;
    case em_SendMsg:
        switch(msg.m_contentType)
        {
        case em_TextMessage:
            {
                MessageOfText *text = (MessageOfText*)msg.m_msgContent;
                dataStream << *text;
            }
            break;
        case em_VoiceMessage:
            break;
        case em_VideoMessage:
            break;
        default:
            break;
        }
        break;
    case em_Any:
        switch(msg.m_contentType)
        {
        case em_TextMessage:
            {
                MessageOfTransfer *tran = (MessageOfTransfer*)msg.m_msgContent;
                dataStream << *tran;
            }
            break;
        case em_VoiceMessage:
            break;
        case em_VideoMessage:
            break;
        default:
            break;
        }
        break;
    }
    return dataStream;
}

QDataStream & operator >> (QDataStream &dataStream, Message &msg)
{
    qint16 msgType;
    qint16 contentType;
    dataStream >> msgType >> contentType >> msg.m_clientID;
    msg.m_msgType = (MessageType)msgType;
    msg.m_contentType = (ContentType)contentType;

    switch(msg.m_msgType)
    {
    case em_Request:
        switch(msg.m_contentType)
        {
        case em_ChangeState:
            {
                ClientChangeState *changeState = new ClientChangeState();
                dataStream >> (*changeState);
                msg.m_msgContent = (void *)changeState;
            }
            break;
        default:
            break;
        }
        break;
    case em_Response:
        switch(msg.m_contentType)
        {
        case em_ChangeState:
            {
                MessageOfLoginResp *loginResp = new MessageOfLoginResp();
                dataStream >> (*loginResp);
                msg.m_msgContent = (void *)loginResp;
            }
            break;
        default:
            break;
        }
        break;
    case em_Indicator:
        switch(msg.m_contentType)
        {
        case em_ChangeState:
            {
                ClientChangeState *changeState = new ClientChangeState();
                dataStream >> (*changeState);
                msg.m_msgContent = (void *)changeState;
            }
            break;
        default:
            break;
        }
        break;
    case em_SendMsg:
        switch(msg.m_contentType)
        {
        case em_TextMessage:
            {
                MessageOfText *text = new MessageOfText();
                dataStream >> (*text);
                msg.m_msgContent = (void*)text;
            }
            break;
        case em_VoiceMessage:
            break;
        case em_VideoMessage:
            break;
        default:
            break;
        }
        break;
    case em_Any:
        switch(msg.m_contentType)
        {
        case em_TextMessage:
            {
                MessageOfTransfer *tran = new  MessageOfTransfer();
                dataStream >> (*tran);
                msg.m_msgContent = (void*)tran;
            }
            break;
        case em_VoiceMessage:
            break;
        case em_VideoMessage:
            break;
        default:
            break;
        }
        break;
    }
    return dataStream;
}

/**************************************************************
* �������ƣ�MessageOfTransfer << and >>
***************************************************************/
MessageOfTransfer::MessageOfTransfer()
{

}

QDataStream & operator << (QDataStream &dataStream, MessageOfTransfer &tran)
{
    dataStream << tran.m_content;
    return dataStream;
}

QDataStream & operator >> (QDataStream &dataStream, MessageOfTransfer &tran)
{
    dataStream >> tran.m_content;
    return dataStream;
}

/**************************************************************
* �������ƣ�ClientChangeState << and >>
***************************************************************/
QDataStream & operator << (QDataStream &dataStream, ClientChangeState &changeState)
{
    dataStream << (qint16)changeState.m_userState << changeState.m_password;
    return dataStream;
}

QDataStream & operator >> (QDataStream &dataStream, ClientChangeState &changeState)
{
    qint16 state;
    dataStream >> state >> changeState.m_password;
    changeState.m_userState = (UserState)state;
    return dataStream;
}

/**************************************************************
* �������ƣ�MessageOfLoginResp << and >>
***************************************************************/
MessageOfLoginResp::MessageOfLoginResp()
{

}

MessageOfLoginResp::~MessageOfLoginResp()
{
    for(int i = 0; i < this->m_friendsNum; ++i)
    {
        delete this->m_friendsInfo.at(i);
    }
}

QDataStream & operator << (QDataStream &dataStream, MessageOfLoginResp &loginResp)
{
    dataStream << loginResp.m_friendsNum;
    if(loginResp.m_friendsNum <= 0)
    {
        return dataStream;
    }

    for(int i = 0; i < loginResp.m_friendsNum; ++i)
    {
        dataStream << loginResp.m_friendsInfo[i]->m_userID << (qint16)loginResp.m_friendsInfo[i]->m_userState;
    }
    return dataStream;
}

QDataStream & operator >> (QDataStream &dataStream, MessageOfLoginResp &loginResp)
{
    dataStream >> loginResp.m_friendsNum;
    if(loginResp.m_friendsNum <= 0)
    {
        return dataStream;
    }

    for(int i = 0; i < loginResp.m_friendsNum; ++i)
    {
        qint16 userState;
        UserInfo *friendsInfo = new UserInfo;
        dataStream >> friendsInfo->m_userID >> userState;
        friendsInfo->m_userState = (UserState)userState;
        loginResp.m_friendsInfo.append(friendsInfo);
    }
    return dataStream;
}

/**************************************************************
* �������ƣ�MessageOfText << and >>
***************************************************************/
QDataStream & operator << (QDataStream &dataStream, MessageOfText &textMsg)
{
    dataStream << (qint16)textMsg.m_chatType << textMsg.m_friendsNum;
    for(int i = 0; i < textMsg.m_friendsNum; ++i)
    {
        dataStream << textMsg.m_friends[i];
    }
    dataStream << textMsg.m_content;
    return dataStream;
}

QDataStream & operator >> (QDataStream &dataStream, MessageOfText &textMsg)
{
    qint16 chatType;
    dataStream >> chatType >> textMsg.m_friendsNum;
    textMsg.m_chatType = (ChatType)chatType;
    for(int i = 0; i < textMsg.m_friendsNum; ++i)
    {
        QString friendID;
        dataStream >> friendID;
        textMsg.m_friends.append(friendID);
    }
    dataStream >> textMsg.m_content;
    return dataStream;
}
