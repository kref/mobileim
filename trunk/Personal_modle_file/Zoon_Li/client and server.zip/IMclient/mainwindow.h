#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <QtNetwork/QTcpSocket>
#include <QtNetwork/QAbstractSocket>
#include <QtNetwork/QHostAddress>

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    void changeEvent(QEvent *e);

private slots:
    void socketStatusChange(QAbstractSocket::SocketState state);
    void sendMessage();
    void connectSocket();
    void disconnectSocket();
    void connButtonClick();

private:
    void changeInfoLabel(QString s);
    void appendHistory(QString s);

private:
    Ui::MainWindow *ui;
    QTcpSocket *socket;
    QString id;
};

#endif // MAINWINDOW_H
