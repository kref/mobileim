#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    socket(0),
    id("1237384")

{
    ui->setupUi(this);
    ui->connectButton->setText("connect");
    connect(ui->closeButton,SIGNAL(clicked()),this,SLOT(close()));
    connect(ui->sendButton,SIGNAL(clicked()),this,SLOT(sendMessage()));
    connect(ui->connectButton,SIGNAL(clicked()),this,SLOT(connButtonClick()));
}

MainWindow::~MainWindow()
{
    delete ui;
    delete socket;
}

void MainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void MainWindow::connButtonClick()
{
    if(ui->connectButton->text().compare("connect")==0)
    {
        ui->connectButton->setText("disconnect");
        connectSocket();
    }
    else if(ui->connectButton->text().compare("disconnect")==0)
    {
        ui->connectButton->setText("connect");
        disconnectSocket();
    }
}

void MainWindow::connectSocket()
{
    if(!socket)
    {
        socket = new QTcpSocket(this);
        connect(socket,SIGNAL(stateChanged(QAbstractSocket::SocketState)),this,SLOT(socketStatusChange(QAbstractSocket::SocketState)));
        socket->connectToHost(QHostAddress::Any,8900);
    }
}

void MainWindow::disconnectSocket()
{
    if(socket && socket->state()==QAbstractSocket::ConnectedState)
    {
        socket->close();
    }
}

void MainWindow::changeInfoLabel(QString s)
{
     ui->infolabel->setText(s);
}

void MainWindow::socketStatusChange(QAbstractSocket::SocketState state)
{
    switch(state)
    {
    case QAbstractSocket::UnconnectedState:
            this->changeInfoLabel("unconnected.");
            break;
    case QAbstractSocket::ConnectingState:
            this->changeInfoLabel("connecting.");
            break;
    case QAbstractSocket::ConnectedState:
            this->changeInfoLabel("connected.");
            break;
    case QAbstractSocket::ListeningState:
            this->changeInfoLabel("working.");
            break;
    default:
            this->changeInfoLabel("working.");
            break;
    }
}

void MainWindow::appendHistory(QString s)
{
    ui->historyBrowser->append(s);
}

void MainWindow::sendMessage()
{
    QString message = ui->messageEdit->toPlainText();
    this->appendHistory(id + ": " + message);
    socket->write(message.toUtf8() + "\r\n");
    ui->messageEdit->clear();
}
