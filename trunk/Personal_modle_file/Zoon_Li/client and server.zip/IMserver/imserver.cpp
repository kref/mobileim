#include "imserver.h"

IMserver::IMserver(QObject *parent = 0) : QTcpServer(parent)
{
    label = new QLabel();
    this->listen(QHostAddress::Any,8900);
    connect(this,SIGNAL(newConnection()),this,SLOT(connComing()));
}

IMserver::~IMserver()
{
    for(int i=0 ; i<clients.count() ; i++)
    {
        delete clients.at(i);
    }
    delete label;
}

void IMserver::incomingConnection ( int socketDescriptor )
{
    QTcpSocket *clientSocket = new QTcpSocket(this);
    clientSocket->setSocketDescriptor(socketDescriptor);
    connect(clientSocket,SIGNAL(readyRead()),this,SLOT(recvMessage()));
    clients.append(clientSocket);
    emit newConnection();
}

void IMserver::connComing()
{
    label->setText("A client is connected!");
    label->show();
}

void IMserver::recvMessage()
{
    label->setText("recviced a message.");
    label->show();
}
