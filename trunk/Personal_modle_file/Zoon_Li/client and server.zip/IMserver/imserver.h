#ifndef IMSERVER_H
#define IMSERVER_H
#include <QtNetwork/QTcpServer>
#include <QtNetwork/QTcpSocket>
#include <QtNetwork/QHostAddress>
#include <QLabel>

class IMserver : QTcpServer
{
    Q_OBJECT
public:
    IMserver(QObject *parent);
    ~IMserver();

protected:
    void incomingConnection ( int socketDescriptor );

private slots:
    void connComing();
    void recvMessage();

private:
    QList<QTcpSocket *> clients;
    QLabel *label;
};

#endif // IMSERVER_H
