#include <QApplication>
#include "imserver.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    IMserver server(0);
    return a.exec();
}
